package com.bestbuy.ebs.service;


public interface SppsService {

	public void insertData(String data);
	
}
