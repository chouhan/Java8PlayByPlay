package com.bestbuy.ebs.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bestbuy.ebs.model.QueueData;

public interface SppsRepository extends JpaRepository<QueueData, Integer>{

}
