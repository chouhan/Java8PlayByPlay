package com.bestbuy.ebs.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bestbuy.ebs.model.QueueData;
import com.bestbuy.ebs.repository.SppsRepository;


@Service
public class SppsServiceImpl implements SppsService {
	
	@Autowired
	private SppsRepository sppsRepository;

	@Override
	public void insertData(String data) {
		QueueData queueData = new QueueData();
		queueData.setText(data);
		sppsRepository.save(queueData);
	}


}
