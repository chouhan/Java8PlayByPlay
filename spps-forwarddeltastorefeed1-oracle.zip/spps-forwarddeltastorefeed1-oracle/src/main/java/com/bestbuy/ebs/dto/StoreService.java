
package com.bestbuy.ebs.dto;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class StoreService {

    @JsonProperty("serviceCode")
    private String serviceCode;
    @JsonProperty("shipToAccount")
    private String shipToAccount;
    @JsonProperty("soldToAccount")
    private String soldToAccount;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("serviceCode")
    public String getServiceCode() {
        return serviceCode;
    }

    @JsonProperty("serviceCode")
    public void setServiceCode(String serviceCode) {
        this.serviceCode = serviceCode;
    }

    @JsonProperty("shipToAccount")
    public String getShipToAccount() {
        return shipToAccount;
    }

    @JsonProperty("shipToAccount")
    public void setShipToAccount(String shipToAccount) {
        this.shipToAccount = shipToAccount;
    }

    @JsonProperty("soldToAccount")
    public String getSoldToAccount() {
        return soldToAccount;
    }

    @JsonProperty("soldToAccount")
    public void setSoldToAccount(String soldToAccount) {
        this.soldToAccount = soldToAccount;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
