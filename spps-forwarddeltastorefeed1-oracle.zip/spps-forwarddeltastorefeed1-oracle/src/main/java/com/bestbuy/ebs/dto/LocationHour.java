
package com.bestbuy.ebs.dto;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class LocationHour {

    @JsonProperty("weekStartSundayDate")
    private String weekStartSundayDate;
    @JsonProperty("sunOpenTime")
    private String sunOpenTime;
    @JsonProperty("sunCloseTime")
    private String sunCloseTime;
    @JsonProperty("monOpenTime")
    private String monOpenTime;
    @JsonProperty("monCloseTime")
    private String monCloseTime;
    @JsonProperty("tueOpenTime")
    private String tueOpenTime;
    @JsonProperty("tueCloseTime")
    private String tueCloseTime;
    @JsonProperty("wedOpenTime")
    private String wedOpenTime;
    @JsonProperty("wedCloseTime")
    private String wedCloseTime;
    @JsonProperty("thuOpenTime")
    private String thuOpenTime;
    @JsonProperty("thuCloseTime")
    private String thuCloseTime;
    @JsonProperty("friOpenTime")
    private String friOpenTime;
    @JsonProperty("friCloseTime")
    private String friCloseTime;
    @JsonProperty("satOpenTime")
    private String satOpenTime;
    @JsonProperty("satCloseTime")
    private String satCloseTime;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("weekStartSundayDate")
    public String getWeekStartSundayDate() {
        return weekStartSundayDate;
    }

    @JsonProperty("weekStartSundayDate")
    public void setWeekStartSundayDate(String weekStartSundayDate) {
        this.weekStartSundayDate = weekStartSundayDate;
    }

    @JsonProperty("sunOpenTime")
    public String getSunOpenTime() {
        return sunOpenTime;
    }

    @JsonProperty("sunOpenTime")
    public void setSunOpenTime(String sunOpenTime) {
        this.sunOpenTime = sunOpenTime;
    }

    @JsonProperty("sunCloseTime")
    public String getSunCloseTime() {
        return sunCloseTime;
    }

    @JsonProperty("sunCloseTime")
    public void setSunCloseTime(String sunCloseTime) {
        this.sunCloseTime = sunCloseTime;
    }

    @JsonProperty("monOpenTime")
    public String getMonOpenTime() {
        return monOpenTime;
    }

    @JsonProperty("monOpenTime")
    public void setMonOpenTime(String monOpenTime) {
        this.monOpenTime = monOpenTime;
    }

    @JsonProperty("monCloseTime")
    public String getMonCloseTime() {
        return monCloseTime;
    }

    @JsonProperty("monCloseTime")
    public void setMonCloseTime(String monCloseTime) {
        this.monCloseTime = monCloseTime;
    }

    @JsonProperty("tueOpenTime")
    public String getTueOpenTime() {
        return tueOpenTime;
    }

    @JsonProperty("tueOpenTime")
    public void setTueOpenTime(String tueOpenTime) {
        this.tueOpenTime = tueOpenTime;
    }

    @JsonProperty("tueCloseTime")
    public String getTueCloseTime() {
        return tueCloseTime;
    }

    @JsonProperty("tueCloseTime")
    public void setTueCloseTime(String tueCloseTime) {
        this.tueCloseTime = tueCloseTime;
    }

    @JsonProperty("wedOpenTime")
    public String getWedOpenTime() {
        return wedOpenTime;
    }

    @JsonProperty("wedOpenTime")
    public void setWedOpenTime(String wedOpenTime) {
        this.wedOpenTime = wedOpenTime;
    }

    @JsonProperty("wedCloseTime")
    public String getWedCloseTime() {
        return wedCloseTime;
    }

    @JsonProperty("wedCloseTime")
    public void setWedCloseTime(String wedCloseTime) {
        this.wedCloseTime = wedCloseTime;
    }

    @JsonProperty("thuOpenTime")
    public String getThuOpenTime() {
        return thuOpenTime;
    }

    @JsonProperty("thuOpenTime")
    public void setThuOpenTime(String thuOpenTime) {
        this.thuOpenTime = thuOpenTime;
    }

    @JsonProperty("thuCloseTime")
    public String getThuCloseTime() {
        return thuCloseTime;
    }

    @JsonProperty("thuCloseTime")
    public void setThuCloseTime(String thuCloseTime) {
        this.thuCloseTime = thuCloseTime;
    }

    @JsonProperty("friOpenTime")
    public String getFriOpenTime() {
        return friOpenTime;
    }

    @JsonProperty("friOpenTime")
    public void setFriOpenTime(String friOpenTime) {
        this.friOpenTime = friOpenTime;
    }

    @JsonProperty("friCloseTime")
    public String getFriCloseTime() {
        return friCloseTime;
    }

    @JsonProperty("friCloseTime")
    public void setFriCloseTime(String friCloseTime) {
        this.friCloseTime = friCloseTime;
    }

    @JsonProperty("satOpenTime")
    public String getSatOpenTime() {
        return satOpenTime;
    }

    @JsonProperty("satOpenTime")
    public void setSatOpenTime(String satOpenTime) {
        this.satOpenTime = satOpenTime;
    }

    @JsonProperty("satCloseTime")
    public String getSatCloseTime() {
        return satCloseTime;
    }

    @JsonProperty("satCloseTime")
    public void setSatCloseTime(String satCloseTime) {
        this.satCloseTime = satCloseTime;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
