package com.bestbuy.ebs.util;

import com.google.gson.Gson;

public class Converter {

  public static String objToJson(Object obj) {
      Gson gson = new Gson();
      return gson.toJson(obj);
  }

}
