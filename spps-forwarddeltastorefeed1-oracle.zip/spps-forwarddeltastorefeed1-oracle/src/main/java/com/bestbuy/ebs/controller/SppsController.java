package com.bestbuy.ebs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import com.bestbuy.ebs.receiver.MessageReceiver;

@RestController
public class SppsController {
	
	@Autowired
	private MessageReceiver receiver;
	
	@PostMapping("spps/insert")
	public void insertData() {
		this.receiver.dumpData();
	}
	
}
