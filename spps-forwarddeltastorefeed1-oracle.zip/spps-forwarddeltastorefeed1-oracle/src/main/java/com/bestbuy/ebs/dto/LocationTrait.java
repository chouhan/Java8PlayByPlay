
package com.bestbuy.ebs.dto;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class LocationTrait {

    @JsonProperty("trait")
    private int trait;
    @JsonProperty("traitDescriptioRef")
    private String traitDescriptioRef;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("trait")
    public int getTrait() {
        return trait;
    }

    @JsonProperty("trait")
    public void setTrait(int trait) {
        this.trait = trait;
    }

    @JsonProperty("traitDescriptioRef")
    public String getTraitDescriptioRef() {
        return traitDescriptioRef;
    }

    @JsonProperty("traitDescriptioRef")
    public void setTraitDescriptioRef(String traitDescriptioRef) {
        this.traitDescriptioRef = traitDescriptioRef;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
