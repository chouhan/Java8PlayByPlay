package com.bestbuy.ebs.config;

public class MQConfig {

    public static final String qName = "DEV.QUEUE.1";
}
