package com.bestbuy.ebs.receiver;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bestbuy.ebs.dto.AttachedLocation;
import com.bestbuy.ebs.dto.JsonDataResponseDTO;
import com.bestbuy.ebs.dto.LocationFunction;
import com.bestbuy.ebs.dto.LocationHour;
import com.bestbuy.ebs.service.SppsService;
import com.bestbuy.ebs.util.Converter;

@Component
public class MessageReceiver {

	@Autowired
	private SppsService sppsService;

//    @JmsListener(destination = MQConfig.qName)
    public void receiveMessage(String msg) {
        System.out.println();
        System.out.println("========================================");
        System.out.println("Received message is: " + msg);
        System.out.println("========================================");

    }
    

	
    public void dumpData() {
    	
    	List<AttachedLocation> attachedLocationList = new ArrayList<>();
    	AttachedLocation attachedLocations = new AttachedLocation();
    	attachedLocations.setAssociationType("Service Center");
    	attachedLocations.setLocationId("610");
    	attachedLocationList.add(attachedLocations);
    	
    	List<LocationFunction> locationFunctionList = new ArrayList<>();
    	LocationFunction locationFunction = new LocationFunction();
    	locationFunction.setFunctionCode("1505");
    	locationFunctionList.add(locationFunction);
    	
    	List<LocationHour> locationHourList = new ArrayList<>();
    	LocationHour locationHour = new LocationHour();
    	locationHour.setFriCloseTime("12506");
    	locationHour.setFriOpenTime("1056");
    	locationHour.setMonCloseTime("125635");
    	locationHour.setMonOpenTime("1526345");
    	locationHour.setSatCloseTime("546543413");
    	locationHour.setSatOpenTime("setopoen");
    	locationHour.setSunCloseTime("lsdfjlskdf");
    	locationHour.setSunOpenTime("65456454");
    	locationHour.setThuCloseTime("lksdjflkjsd");
    	locationHour.setThuOpenTime("jlksjdklfj");
    	locationHour.setTueCloseTime("54665465");
    	locationHour.setTueOpenTime("lkjskldfkl");
    	locationHour.setWedCloseTime("lkjsdlkjf");
    	locationHour.setWedOpenTime("ljsdlkfj");
    	locationHour.setWeekStartSundayDate("ljsdfjl");
    	locationHourList.add(locationHour);
    	
    	JsonDataResponseDTO response = new JsonDataResponseDTO();
    	response.setMessageType("STORE_PUBLISH");
    	response.setVersion("1.1");
    	response.setPublishType("intraday");
    	response.setPublishTimestamp("2018-05-25");
    	response.setUuid("STRPSC2589456");
    	response.setLocationId(281);
    	response.setName("RICHFIELD");
    	response.setDetailDesc("RICHFIELD");
    	response.setChannel(110);
    	response.setAddress1("100 WEST 78TH");
    	response.setAddress2("SUIT 101");
    	response.setCity("MN");
    	response.setState("mn");
    	response.setCountry("us");
    	response.setAttachedLocations(attachedLocationList);
    	response.setLocationFunctions(locationFunctionList);
    	response.setLocationHours(locationHourList);
    	this.sppsService.insertData(Converter.objToJson(response));
    			
    }
}
