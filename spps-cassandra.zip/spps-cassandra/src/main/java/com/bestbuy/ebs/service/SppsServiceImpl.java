package com.bestbuy.ebs.service;

import com.bestbuy.ebs.model.Spps;
import com.bestbuy.ebs.repository.SppsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;
import java.util.List;


@Service
public class SppsServiceImpl implements SppsService {


    @Autowired
    private SppsRepository sppsRepository;

	@Override
	public void insertData(String data) {
		
		Spps spps = new Spps();
		spps.setId(3);
		spps.setJsondata(data);
		spps.setLast_processed_timestamp(null);
		spps.setLast_updated_timestamp(null);
		spps.setMessage_type("A");
		spps.setStatus("Warning");
		sppsRepository.save(spps);
		
	}




}
