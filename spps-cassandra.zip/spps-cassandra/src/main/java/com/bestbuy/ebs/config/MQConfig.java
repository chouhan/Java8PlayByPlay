package com.bestbuy.ebs.config;

public class MQConfig {

    public static final String qName_ibm = "DEV.QUEUE.1";
    // NT-REMOVE
    public static final String qName_apache = "spps.queue";
}
