package com.bestbuy.ebs.model;


import lombok.Data;

import java.sql.Timestamp;

import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("spps")
@Data
public class Spps {

    @PrimaryKey
    private int id;
    private String jsondata;
    private String message_type;
    private String status;
    private Timestamp last_updated_timestamp;
    private Timestamp last_processed_timestamp;
    
}
