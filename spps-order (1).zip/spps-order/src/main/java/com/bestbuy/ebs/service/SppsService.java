package com.bestbuy.ebs.service;




import com.bestbuy.ebs.dto.OracleQData;
import com.bestbuy.ebs.dto.Root;
import com.bestbuy.ebs.model.POUpdate;

import java.util.Collection;
import java.util.List;

public interface SppsService {

    void createPO(OracleQData msg);

    void savePONumber(OracleQData oracleRequest, Root poResponse);
	
}
