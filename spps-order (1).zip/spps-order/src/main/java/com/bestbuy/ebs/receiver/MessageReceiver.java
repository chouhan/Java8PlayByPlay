package com.bestbuy.ebs.receiver;

import com.bestbuy.ebs.config.MQConfig;
import com.bestbuy.ebs.dto.JsonDataResponseDTO;
import com.bestbuy.ebs.dto.OracleQData;
import com.bestbuy.ebs.service.SppsService;
import com.bestbuy.ebs.util.Converter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Component;

@Component
public class MessageReceiver {

	@Autowired
	private SppsService sppsService;

    @JmsListener(destination = "oracle_queue")
    @SendTo("outbound.queue")
    public void receiveMessage(OracleQData oracleInput) {
        System.out.println();
        System.out.println("========================================");
        System.out.println("Received message is: " + Converter.objToJson(oracleInput));
        System.out.println("========================================");
        this.sppsService.createPO(oracleInput);

    }

}
