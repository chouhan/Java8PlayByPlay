package com.bestbuy.ebs.repository;

import com.bestbuy.ebs.model.POUpdate;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface POUpdateRepository extends CrudRepository<POUpdate, String> {



}

