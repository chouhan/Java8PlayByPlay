package com.bestbuy.ebs.util;

import com.bestbuy.ebs.dto.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

// NT-REMOVE
@Component
public class MessageSender {

   /* @Autowired
    private Queue queue;
*/
    @Autowired
    private JmsTemplate jmsTemplate;

    public void sendMessage(String messageType) {
        this.jmsTemplate.convertAndSend("oracle_queue", createQueueData());
        System.out.println("Message has been put to queue by sender");
    }

    public void sendCreatePOResponse(String response) {
        this.jmsTemplate.convertAndSend("create_order_response", response);
        System.out.println("Create PO Response Message has been put to queue by sender");
    }


   /* public void run(String... arg0) throws Exception {
        // This will put text message to queue
        this.jmsTemplate.convertAndSend(this.queue, dumpData());
        System.out.println("Message has been put to queue by sender");
    }*/


   private OracleQData createQueueData() {
       List<PartTB> partTBS = new ArrayList<PartTB>();
       PartTB partTB1 = new PartTB();
       partTB1.setSeqNo("1");
       partTB1.setPartNo("DC92-01802A");
       partTB1.setQty("1");

       PartTB partTB2 = new PartTB();
       partTB2.setSeqNo("2");
       partTB2.setPartNo("DC92-01802B");
       partTB2.setQty("1");
       partTBS.add(partTB1);
       partTBS.add(partTB2);

       OracleQData oracleQData = new OracleQData();
       oracleQData.setPartTB(partTBS);
       oracleQData.setASCNo("0123456789");
       oracleQData.setCompany("Samsung");
       oracleQData.setPono("TICKET_TEST_JKF_1");
       oracleQData.setShipTo("0123456789");
       oracleQData.setPOType("ABC");

       return oracleQData;

   }


    public JsonDataResponseDTO dumpData(String messageType) {

        List<AttachedLocation> attachedLocationList = new ArrayList<>();
        AttachedLocation attachedLocations = new AttachedLocation();
        attachedLocations.setAssociationType("Service Center");
        attachedLocations.setLocationId("610");
        attachedLocationList.add(attachedLocations);

        List<LocationFunction> locationFunctionList = new ArrayList<>();
        LocationFunction locationFunction = new LocationFunction();
        locationFunction.setFunctionCode("1505");
        locationFunctionList.add(locationFunction);

        List<LocationHour> locationHourList = new ArrayList<>();
        LocationHour locationHour = new LocationHour();
        locationHour.setFriCloseTime("12506");
        locationHour.setFriOpenTime("1056");
        locationHour.setMonCloseTime("125635");
        locationHour.setMonOpenTime("1526345");
        locationHour.setSatCloseTime("546543413");
        locationHour.setSatOpenTime("setopoen");
        locationHour.setSunCloseTime("lsdfjlskdf");
        locationHour.setSunOpenTime("65456454");
        locationHour.setThuCloseTime("lksdjflkjsd");
        locationHour.setThuOpenTime("jlksjdklfj");
        locationHour.setTueCloseTime("54665465");
        locationHour.setTueOpenTime("lkjskldfkl");
        locationHour.setWedCloseTime("lkjsdlkjf");
        locationHour.setWedOpenTime("ljsdlkfj");
        locationHour.setWeekStartSundayDate("ljsdfjl");
        locationHourList.add(locationHour);

        JsonDataResponseDTO response = new JsonDataResponseDTO();
        response.setMessageType(messageType);  //STORE_PUBLISH
        response.setVersion("1.1");
        response.setPublishType("intraday");
        response.setPublishTimestamp("2018-05-25");
        response.setUuid("STRPSC2589456");
        response.setLocationId(281);
        response.setName("RICHFIELD");
        response.setDetailDesc("RICHFIELD");
        response.setChannel(110);
        response.setAddress1("100 WEST 78TH");
        response.setAddress2("SUIT 101");
        response.setCity("MN");
        response.setState("mn");
        response.setCountry("us");
        response.setAttachedLocations(attachedLocationList);
        response.setLocationFunctions(locationFunctionList);
        response.setLocationHours(locationHourList);

        return response;
    }



}
