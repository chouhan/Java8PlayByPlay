package com.bestbuy.ebs.service;


import com.bestbuy.ebs.dto.OracleQData;
import com.bestbuy.ebs.dto.Root;
import com.bestbuy.ebs.model.POUpdate;
import com.bestbuy.ebs.repository.POUpdateRepository;
import com.bestbuy.ebs.util.Converter;
import com.bestbuy.ebs.util.MessageSender;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;


@Service
public class SppsServiceImpl implements SppsService {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private MessageSender sender;

    @Autowired
    private POUpdateRepository poUpdateRepository;


    @Override
    public void createPO(OracleQData oracleRequest) {

        String pORequest = Converter.objToJson(oracleRequest);

        // Calling PO Service
        Root preCheckPOResponse = precheckPOCall(pORequest);

        if(preCheckPOResponse.getRootdoc().getRetCode() == 0)
        {
            String createStrPOResponse = createPOCall(pORequest);

            Root createObjPOResponse = Converter.jsonResponseToObj(createStrPOResponse);

            // Save PO number in Cassandra
            savePONumber(oracleRequest,createObjPOResponse);

            // Enqueue in Rabbit MQ
            sender.sendCreatePOResponse(createStrPOResponse);
        }
    }

    @Override
    public void savePONumber(OracleQData oracleRequest, Root poResponse) {
        POUpdate poUpdate = new POUpdate();
        poUpdate.setId(1);
        poUpdate.setAscno(Long.valueOf(oracleRequest.getASCNo()));
        poUpdate.setCompany(oracleRequest.getCompany());
        poUpdate.setBbyPoNumber("");
        poUpdate.setVendorPoNumber("");
        poUpdate.setLastCreatedTimestamp(null);
        poUpdate.setLastUpdatedTimestamp(null);
        poUpdate.setStatus("Created");
        poUpdateRepository.save(poUpdate);

    }

    private Root precheckPOCall(String jsonRequest) {
        String str="http://localhost:8082/spps/sam/preCheckPO";
        URI uri = URI.create(str);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("clientId","BU3JgqOMjYtvbZIPW1gpqpxq");
        headers.set("clientCode","MRP");
        headers.set("clientSecret","Test");
        HttpEntity<String> request = new HttpEntity<String>(jsonRequest, headers);
       // String preCheckPOResponse = restTemplate.postForObject(uri, request, String.class);
        String res = "{\"rootdoc\":{\"PODate\":20210707,\"Table\":{\"Column\":[{\"Type\":\"String\",\"Name\":\"SeqNo\"},{\"Type\":\"String\",\"Name\":\"POPartNo\"},{\"Type\":\"String\",\"Name\":\"SOPartNo\"},{\"Type\":\"String\",\"Name\":\"Description\"},{\"Type\":\"Decimal\",\"Name\":\"Qty\"},{\"Type\":\"Decimal\",\"Name\":\"SalesPrice\"},{\"Type\":\"Decimal\",\"Name\":\"SalesAmt\"},{\"Type\":\"String\",\"Name\":\"StockAvailibility\"},{\"Type\":\"String\",\"Name\":\"Remarks\"},{\"Type\":\"String\",\"Name\":\"SONo\"},{\"Type\":\"String\",\"Name\":\"ServiceStatus\"},{\"Type\":\"String\",\"Name\":\"ETD\"},{\"Type\":\"String\",\"Name\":\"ShippingMethod\"},{\"Type\":\"String\",\"Name\":\"TicketNo\"},{\"Type\":\"String\",\"Name\":\"ShipFrom\"},{\"Type\":\"String\",\"Name\":\"ETA\"},{\"Type\":\"String\",\"Name\":\"ServiceDate\"},{\"Type\":\"String\",\"Name\":\"Reason\"}],\"ROW\":[{\"SeqNo\":10,\"ShippingMethod\":\"\",\"Description\":\"Please check data !!\",\"ShipFrom\":\"\",\"POPartNo\":\"DC92-01802A\",\"SOPartNo\":\"DC92-01802A\",\"Reason\":\"\",\"SalesPrice\":0,\"SalesAmt\":0,\"ServiceDate\":\"\",\"ETA\":\"\",\"ETD\":\"00000000\",\"Remarks\":\"EVP200No customer master record exists for customer 123\",\"ServiceStatus\":\"\",\"Qty\":1,\"TicketNo\":\"\",\"StockAvailibility\":\"N\"},{\"SeqNo\":20,\"ShippingMethod\":\"\",\"Description\":\"Please check data !!\",\"ShipFrom\":\"\",\"POPartNo\":\"DC92-01802B\",\"SOPartNo\":\"DC92-01802B\",\"Reason\":\"\",\"SalesPrice\":0,\"SalesAmt\":0,\"ServiceDate\":\"\",\"ETA\":\"\",\"ETD\":\"00000000\",\"Remarks\":\"EVP200No customer master record exists for customer 123\",\"ServiceStatus\":\"\",\"Qty\":1,\"TicketNo\":\"\",\"StockAvailibility\":\"N\"}],\"Name\":\"PartTB\"},\"RetCode\":0,\"ErrMsg\":\"EVP200No customer master record exists for customer 123\",\"AccountNo\":\"0123456789\",\"PONo\":\"\",\"ShipTo\":\"0123456789\"}}";
        Root preCheckPOresponse = Converter.jsonResponseToObj(res);
        return preCheckPOresponse;
    }

    private String createPOCall(String jsonRequest) {
        String str="http://localhost:8082/spps/sam/createPo";
        URI uri = URI.create(str);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("clientId","BU3JgqOMjYtvbZIPW1gpqpxq");
        headers.set("clientCode","MRP");
        headers.set("clientSecret","Test");
        HttpEntity<String> request = new HttpEntity<String>(jsonRequest, headers);
        // String preCheckPOResponse = restTemplate.postForObject(uri, request, String.class);
        String res = "{\"rootdoc\":{\"PODate\":20210707,\"Table\":{\"Column\":[{\"Type\":\"String\",\"Name\":\"SeqNo\"},{\"Type\":\"String\",\"Name\":\"POPartNo\"},{\"Type\":\"String\",\"Name\":\"SOPartNo\"},{\"Type\":\"String\",\"Name\":\"Description\"},{\"Type\":\"Decimal\",\"Name\":\"Qty\"},{\"Type\":\"Decimal\",\"Name\":\"SalesPrice\"},{\"Type\":\"Decimal\",\"Name\":\"SalesAmt\"},{\"Type\":\"String\",\"Name\":\"StockAvailibility\"},{\"Type\":\"String\",\"Name\":\"Remarks\"},{\"Type\":\"String\",\"Name\":\"SONo\"},{\"Type\":\"String\",\"Name\":\"ServiceStatus\"},{\"Type\":\"String\",\"Name\":\"ETD\"},{\"Type\":\"String\",\"Name\":\"ShippingMethod\"},{\"Type\":\"String\",\"Name\":\"TicketNo\"},{\"Type\":\"String\",\"Name\":\"ShipFrom\"},{\"Type\":\"String\",\"Name\":\"ETA\"},{\"Type\":\"String\",\"Name\":\"ServiceDate\"},{\"Type\":\"String\",\"Name\":\"Reason\"}],\"ROW\":[{\"SeqNo\":10,\"ShippingMethod\":\"\",\"Description\":\"Please check data !!\",\"ShipFrom\":\"\",\"POPartNo\":\"DC92-01802A\",\"SOPartNo\":\"DC92-01802A\",\"Reason\":\"\",\"SalesPrice\":0,\"SalesAmt\":0,\"ServiceDate\":\"\",\"ETA\":\"\",\"ETD\":\"00000000\",\"Remarks\":\"EVP200No customer master record exists for customer 123\",\"ServiceStatus\":\"\",\"Qty\":1,\"TicketNo\":\"\",\"StockAvailibility\":\"N\"},{\"SeqNo\":20,\"ShippingMethod\":\"\",\"Description\":\"Please check data !!\",\"ShipFrom\":\"\",\"POPartNo\":\"DC92-01802B\",\"SOPartNo\":\"DC92-01802B\",\"Reason\":\"\",\"SalesPrice\":0,\"SalesAmt\":0,\"ServiceDate\":\"\",\"ETA\":\"\",\"ETD\":\"00000000\",\"Remarks\":\"EVP200No customer master record exists for customer 123\",\"ServiceStatus\":\"\",\"Qty\":1,\"TicketNo\":\"\",\"StockAvailibility\":\"N\"}],\"Name\":\"PartTB\"},\"RetCode\":2,\"ErrMsg\":\"EVP200No customer master record exists for customer 123\",\"AccountNo\":\"0123456789\",\"PONo\":\"\",\"ShipTo\":\"0123456789\"}}";
        Root preCheckPOresponse = Converter.jsonResponseToObj(res);
        return res;
    }



}
