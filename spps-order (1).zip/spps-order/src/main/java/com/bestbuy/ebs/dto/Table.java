package com.bestbuy.ebs.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class Table {

    @JsonProperty("Column")
    public List<Column> column;
    @JsonProperty("ROW")
    public List<Row> rOW;
    @JsonProperty("Name")
    public String name;
}
