package com.bestbuy.ebs.model;


import lombok.Data;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import java.sql.Timestamp;

@Table("po_update")
@Data
public class POUpdate {

    @PrimaryKey
    private int id;
    @Column("ascno")
    private long ascno;
    @Column("company")
    private String company;
    @Column("status")
    private String status;
    @Column("bby_po_number")
    private String bbyPoNumber;
    @Column("vendor_po_number")
    private String vendorPoNumber;
    @Column("last_created_timestamp")
    private Timestamp lastCreatedTimestamp;
    @Column("last_updated_timestamp")
    private Timestamp lastUpdatedTimestamp;





}
