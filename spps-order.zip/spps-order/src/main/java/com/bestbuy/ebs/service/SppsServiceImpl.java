package com.bestbuy.ebs.service;


import com.bestbuy.ebs.model.POUpdate;
import com.bestbuy.ebs.repository.POUpdateRepository;
import com.bestbuy.ebs.util.MessageSender;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;


@Service
public class SppsServiceImpl implements SppsService {

    @Autowired
    private RestTemplate template;

    @Autowired
    private MessageSender sender;

    @Autowired
    private POUpdateRepository poUpdateRepository;


    @Override
    public void createPO(String order,String messageType) {

        // Calling PO Service
        if(precheckPOCall().equals("Available")) {
            String poNumber = createPOCall();

            // Save PO number in Cassandra
            savePEONumber(poNumber);

            // Enqueue in Rabbit MQ
            sender.sendCreatePOResponse("Testing Cassandra");
        }
    }

    @Override
    public void savePEONumber(String poNumber) {
        POUpdate poUpdate = new POUpdate();
        poUpdate.setId(1);
        poUpdate.setPeoNumber(poNumber);
        poUpdate.setStatus("Created");
        poUpdateRepository.save(poUpdate);

    }

    private String precheckPOCall() {
        String str="http://localhost:8082/spps/precheckpo";
        URI uri = URI.create(str);
        return template.getForObject(uri,String.class);
    }

    private String createPOCall() {
        String str="http://localhost:8082/spps/createpo";
        URI uri = URI.create(str);
        return template.getForObject(uri,String.class);
    }



}
