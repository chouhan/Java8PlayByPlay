package com.bestbuy.ebs.model;


import lombok.Data;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import java.sql.Timestamp;

@Table("peo_update")
@Data
public class POUpdate {

    @PrimaryKey
    private int id;
    @Column("peo_number")
    private String PeoNumber;
    @Column("status")
    private String status;




}
