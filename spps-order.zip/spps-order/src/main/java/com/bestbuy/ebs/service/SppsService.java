package com.bestbuy.ebs.service;




import com.bestbuy.ebs.model.POUpdate;

import java.util.Collection;
import java.util.List;

public interface SppsService {

    void createPO(String order, String messageType);

    void savePEONumber(String peoNumber);
	
}
