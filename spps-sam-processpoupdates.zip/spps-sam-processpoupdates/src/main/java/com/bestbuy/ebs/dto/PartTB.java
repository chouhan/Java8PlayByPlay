package com.bestbuy.ebs.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class PartTB implements Serializable {

    @JsonProperty("SeqNo")
    private String seqNo;
    @JsonProperty("PartNo")
    private String partNo;
    @JsonProperty("Qty")
    private String qty;


}
