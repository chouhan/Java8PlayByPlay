package com.bestbuy.ebs.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class Rootdoc implements Serializable {
    @JsonProperty("PODate")
    public int pODate;
    @JsonProperty("Table")
    public Table table;
    @JsonProperty("RetCode")
    public int RetCode;
    @JsonProperty("ErrMsg")
    public String errMsg;
    @JsonProperty("AccountNo")
    public String accountNo;
    @JsonProperty("PONo")
    public String pONo;
    @JsonProperty("ShipTo")
    public String shipTo;
}
