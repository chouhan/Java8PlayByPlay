package com.bestbuy.ebs.util;

import com.bestbuy.ebs.dto.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

// NT-REMOVE
@Component
public class MessageSender {

   /* @Autowired
    private Queue queue;
*/
    @Autowired
    private JmsTemplate jmsTemplate;

    public void sendCreatePOResponse() {
        String response = "{\"rootdoc\":{\"PODate\":20210707,\"Table\":{\"Column\":[{\"Type\":\"String\",\"Name\":\"SeqNo\"},{\"Type\":\"String\",\"Name\":\"POPartNo\"},{\"Type\":\"String\",\"Name\":\"SOPartNo\"},{\"Type\":\"String\",\"Name\":\"Description\"},{\"Type\":\"Decimal\",\"Name\":\"Qty\"},{\"Type\":\"Decimal\",\"Name\":\"SalesPrice\"},{\"Type\":\"Decimal\",\"Name\":\"SalesAmt\"},{\"Type\":\"String\",\"Name\":\"StockAvailibility\"},{\"Type\":\"String\",\"Name\":\"Remarks\"},{\"Type\":\"String\",\"Name\":\"SONo\"},{\"Type\":\"String\",\"Name\":\"ServiceStatus\"},{\"Type\":\"String\",\"Name\":\"ETD\"},{\"Type\":\"String\",\"Name\":\"ShippingMethod\"},{\"Type\":\"String\",\"Name\":\"TicketNo\"},{\"Type\":\"String\",\"Name\":\"ShipFrom\"},{\"Type\":\"String\",\"Name\":\"ETA\"},{\"Type\":\"String\",\"Name\":\"ServiceDate\"},{\"Type\":\"String\",\"Name\":\"Reason\"}],\"ROW\":[{\"SeqNo\":10,\"ShippingMethod\":\"\",\"Description\":\"Please check data !!\",\"ShipFrom\":\"\",\"POPartNo\":\"DC92-01802A\",\"SOPartNo\":\"DC92-01802A\",\"Reason\":\"\",\"SalesPrice\":0,\"SalesAmt\":0,\"ServiceDate\":\"\",\"ETA\":\"\",\"ETD\":\"00000000\",\"Remarks\":\"EVP200No customer master record exists for customer 123\",\"ServiceStatus\":\"\",\"Qty\":1,\"TicketNo\":\"\",\"StockAvailibility\":\"N\"},{\"SeqNo\":20,\"ShippingMethod\":\"\",\"Description\":\"Please check data !!\",\"ShipFrom\":\"\",\"POPartNo\":\"DC92-01802B\",\"SOPartNo\":\"DC92-01802B\",\"Reason\":\"\",\"SalesPrice\":0,\"SalesAmt\":0,\"ServiceDate\":\"\",\"ETA\":\"\",\"ETD\":\"00000000\",\"Remarks\":\"EVP200No customer master record exists for customer 123\",\"ServiceStatus\":\"\",\"Qty\":1,\"TicketNo\":\"\",\"StockAvailibility\":\"N\"}],\"Name\":\"PartTB\"},\"RetCode\":2,\"ErrMsg\":\"EVP200No customer master record exists for customer 123\",\"AccountNo\":\"0123456789\",\"PONo\":\"\",\"ShipTo\":\"0123456789\"}}";
        this.jmsTemplate.convertAndSend("spps-sam-rmq-poupdates", response);
        System.out.println("Create PO Response Message has been put to queue by sender");
    }

    public void sendPreCheckPOErrorResponse() {
        String response = "{\"rootdoc\":{\"PODate\":20210707,\"Table\":{\"Column\":[{\"Type\":\"String\",\"Name\":\"SeqNo\"},{\"Type\":\"String\",\"Name\":\"POPartNo\"},{\"Type\":\"String\",\"Name\":\"SOPartNo\"},{\"Type\":\"String\",\"Name\":\"Description\"},{\"Type\":\"Decimal\",\"Name\":\"Qty\"},{\"Type\":\"Decimal\",\"Name\":\"SalesPrice\"},{\"Type\":\"Decimal\",\"Name\":\"SalesAmt\"},{\"Type\":\"String\",\"Name\":\"StockAvailibility\"},{\"Type\":\"String\",\"Name\":\"Remarks\"},{\"Type\":\"String\",\"Name\":\"SONo\"},{\"Type\":\"String\",\"Name\":\"ServiceStatus\"},{\"Type\":\"String\",\"Name\":\"ETD\"},{\"Type\":\"String\",\"Name\":\"ShippingMethod\"},{\"Type\":\"String\",\"Name\":\"TicketNo\"},{\"Type\":\"String\",\"Name\":\"ShipFrom\"},{\"Type\":\"String\",\"Name\":\"ETA\"},{\"Type\":\"String\",\"Name\":\"ServiceDate\"},{\"Type\":\"String\",\"Name\":\"Reason\"}],\"ROW\":[{\"SeqNo\":10,\"ShippingMethod\":\"\",\"Description\":\"Please check data !!\",\"ShipFrom\":\"\",\"POPartNo\":\"DC92-01802A\",\"SOPartNo\":\"DC92-01802A\",\"Reason\":\"\",\"SalesPrice\":0,\"SalesAmt\":0,\"ServiceDate\":\"\",\"ETA\":\"\",\"ETD\":\"00000000\",\"Remarks\":\"EVP200No customer master record exists for customer 123\",\"ServiceStatus\":\"\",\"Qty\":1,\"TicketNo\":\"\",\"StockAvailibility\":\"N\"},{\"SeqNo\":20,\"ShippingMethod\":\"\",\"Description\":\"Please check data !!\",\"ShipFrom\":\"\",\"POPartNo\":\"DC92-01802B\",\"SOPartNo\":\"DC92-01802B\",\"Reason\":\"\",\"SalesPrice\":0,\"SalesAmt\":0,\"ServiceDate\":\"\",\"ETA\":\"\",\"ETD\":\"00000000\",\"Remarks\":\"EVP200No customer master record exists for customer 123\",\"ServiceStatus\":\"\",\"Qty\":1,\"TicketNo\":\"\",\"StockAvailibility\":\"N\"}],\"Name\":\"PartTB\"},\"RetCode\":2,\"ErrMsg\":\"EVP200No customer master record exists for customer 123\",\"AccountNo\":\"0123456789\",\"PONo\":\"\",\"ShipTo\":\"0123456789\"}}";
        this.jmsTemplate.convertAndSend("spps-sam-rmq-poupdates", response);
        System.out.println("PreCheckPOErrorResponse Message has been put to queue by sender");
    }

    public void sendGetPOUpdatesResponse() {
        String response = "{\"rootdoc\":{\"PODate\":20210707,\"Table\":{\"Column\":[{\"Type\":\"String\",\"Name\":\"SeqNo\"},{\"Type\":\"String\",\"Name\":\"POPartNo\"},{\"Type\":\"String\",\"Name\":\"SOPartNo\"},{\"Type\":\"String\",\"Name\":\"Description\"},{\"Type\":\"Decimal\",\"Name\":\"Qty\"},{\"Type\":\"Decimal\",\"Name\":\"SalesPrice\"},{\"Type\":\"Decimal\",\"Name\":\"SalesAmt\"},{\"Type\":\"String\",\"Name\":\"StockAvailibility\"},{\"Type\":\"String\",\"Name\":\"Remarks\"},{\"Type\":\"String\",\"Name\":\"SONo\"},{\"Type\":\"String\",\"Name\":\"ServiceStatus\"},{\"Type\":\"String\",\"Name\":\"ETD\"},{\"Type\":\"String\",\"Name\":\"ShippingMethod\"},{\"Type\":\"String\",\"Name\":\"TicketNo\"},{\"Type\":\"String\",\"Name\":\"ShipFrom\"},{\"Type\":\"String\",\"Name\":\"ETA\"},{\"Type\":\"String\",\"Name\":\"ServiceDate\"},{\"Type\":\"String\",\"Name\":\"Reason\"}],\"ROW\":[{\"SeqNo\":10,\"ShippingMethod\":\"\",\"Description\":\"Please check data !!\",\"ShipFrom\":\"\",\"POPartNo\":\"DC92-01802A\",\"SOPartNo\":\"DC92-01802A\",\"Reason\":\"\",\"SalesPrice\":0,\"SalesAmt\":0,\"ServiceDate\":\"\",\"ETA\":\"\",\"ETD\":\"00000000\",\"Remarks\":\"EVP200No customer master record exists for customer 123\",\"ServiceStatus\":\"\",\"Qty\":1,\"TicketNo\":\"\",\"StockAvailibility\":\"N\"},{\"SeqNo\":20,\"ShippingMethod\":\"\",\"Description\":\"Please check data !!\",\"ShipFrom\":\"\",\"POPartNo\":\"DC92-01802B\",\"SOPartNo\":\"DC92-01802B\",\"Reason\":\"\",\"SalesPrice\":0,\"SalesAmt\":0,\"ServiceDate\":\"\",\"ETA\":\"\",\"ETD\":\"00000000\",\"Remarks\":\"EVP200No customer master record exists for customer 123\",\"ServiceStatus\":\"\",\"Qty\":1,\"TicketNo\":\"\",\"StockAvailibility\":\"N\"}],\"Name\":\"PartTB\"},\"RetCode\":2,\"ErrMsg\":\"EVP200No customer master record exists for customer 123\",\"AccountNo\":\"0123456789\",\"PONo\":\"\",\"ShipTo\":\"0123456789\"}}";
        this.jmsTemplate.convertAndSend("spps-sam-rmq-poupdates", response);
        System.out.println("GetPOUpdatesResponse Message has been put to queue by sender");
    }


    public void sendResponseinOracleAQ(String response) {
        this.jmsTemplate.convertAndSend("spps-sam-oracle-aq-poupdates", response);
        System.out.println("Response has been put to Oracle AQ queue by sender");
    }









}
