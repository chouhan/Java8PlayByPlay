package com.bestbuy.ebs.dto;

import lombok.Data;

import java.io.Serializable;

@Data
public class Root implements Serializable {
    public Rootdoc rootdoc;
}
