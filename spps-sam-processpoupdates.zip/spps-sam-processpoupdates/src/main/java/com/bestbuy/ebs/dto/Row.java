package com.bestbuy.ebs.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class Row implements Serializable {

    @JsonProperty("SeqNo")
    public int seqNo;
    @JsonProperty("ShippingMethod")
    public String shippingMethod;
    @JsonProperty("Description")
    public String description;
    @JsonProperty("ShipFrom")
    public String shipFrom;
    @JsonProperty("POPartNo")
    public String pOPartNo;
    @JsonProperty("SOPartNo")
    public String sOPartNo;
    @JsonProperty("Reason")
    public String reason;
    @JsonProperty("SalesPrice")
    public int salesPrice;
    @JsonProperty("SalesAmt")
    public int salesAmt;
    @JsonProperty("ServiceDate")
    public String serviceDate;
    @JsonProperty("ETA")
    public String eTA;
    @JsonProperty("ETD")
    public String eTD;
    @JsonProperty("Remarks")
    public String remarks;
    @JsonProperty("ServiceStatus")
    public String serviceStatus;
    @JsonProperty("Qty")
    public int qty;
    @JsonProperty("TicketNo")
    public String ticketNo;
    @JsonProperty("StockAvailibility")
    public String stockAvailibility;
}

