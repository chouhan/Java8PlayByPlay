package com.bestbuy.ebs.service;




import com.bestbuy.ebs.dto.OracleQData;
import com.bestbuy.ebs.dto.Root;


import java.util.Collection;
import java.util.List;

public interface SppsService {

    void insertResponseInOracleAQ(String response);
	
}
