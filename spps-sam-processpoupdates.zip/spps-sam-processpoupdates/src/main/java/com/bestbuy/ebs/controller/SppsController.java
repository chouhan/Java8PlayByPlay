package com.bestbuy.ebs.controller;

import com.bestbuy.ebs.util.MessageSender;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import com.bestbuy.ebs.receiver.MessageReceiver;

import java.util.Collection;
import java.util.List;

// NT-REMOVE
@RestController
public class SppsController {

	private static final Logger logger = LoggerFactory.getLogger(SppsController.class);
	
	@Autowired
	private MessageSender sender;
	
	@GetMapping("spps/insert/{responseType}")
	public String insertData(@PathVariable String responseType)
	{
		if(responseType.equals("CreatePO")) {
			sender.sendCreatePOResponse();
		} else if(responseType.equals("PreCheckPOError")) {
			sender.sendPreCheckPOErrorResponse();
		} else if(responseType.equals("GetPOUpdate")) {
			sender.sendGetPOUpdatesResponse();
		}
		return "Insert in Queue and dump in DB Successfully";
	}
	
}
