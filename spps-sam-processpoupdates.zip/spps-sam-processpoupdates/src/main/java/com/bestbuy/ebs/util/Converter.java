package com.bestbuy.ebs.util;

import com.bestbuy.ebs.dto.Root;
import com.bestbuy.ebs.dto.Rootdoc;
import com.google.gson.Gson;

public class Converter {

  public static String objToJson(Object obj) {
      Gson gson = new Gson();
      return gson.toJson(obj);
  }

  public static Root jsonResponseToObj(String json) {
      Gson gson = new Gson();
      Root response = gson.fromJson(json , Root.class);
      return response;
  }


}
