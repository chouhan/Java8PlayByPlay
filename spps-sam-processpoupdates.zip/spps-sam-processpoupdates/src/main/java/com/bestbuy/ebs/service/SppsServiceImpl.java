package com.bestbuy.ebs.service;


import com.bestbuy.ebs.dto.OracleQData;
import com.bestbuy.ebs.dto.Root;
import com.bestbuy.ebs.util.Converter;

import com.bestbuy.ebs.util.MessageSender;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;


@Service
public class SppsServiceImpl implements SppsService {



    @Autowired
    private MessageSender sender;

    @Override
    public void insertResponseInOracleAQ(String response) {
        sender.sendResponseinOracleAQ(response);
    }


}
