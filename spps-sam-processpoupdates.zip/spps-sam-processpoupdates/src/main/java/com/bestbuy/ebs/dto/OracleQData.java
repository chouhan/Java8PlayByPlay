package com.bestbuy.ebs.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class OracleQData implements Serializable {

    @JsonProperty("Company")
    private String company;
    @JsonProperty("ASCNo")
    private String ASCNo;
    @JsonProperty("PONO")
    private String pono;
    @JsonProperty("ShipTo")
    private String shipTo;
    @JsonProperty("POType")
    private String POType;
    @JsonProperty("PartTB")
    private List<PartTB> partTB;
    private String pendingYN = "Y";
    private String shippingMethod = "D1";
}
