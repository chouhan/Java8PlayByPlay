package com.bestbuy.ebs.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class Column implements Serializable {
    @JsonProperty("Type")
    public String type;
    @JsonProperty("Name")
    public String name;
}
