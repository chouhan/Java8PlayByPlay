#spps-forwarddeltastorefeed


gradle build -Dorg.gradle.java.home="C:\\Program Files\\RedHat\\java-11-openjdk-11.0.5-1"