package com.bestbuy.ebs.util;

import com.bestbuy.ebs.config.MQConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Component
public class MessageSender {

    @Autowired
    private JmsTemplate jmsTemplate;

    public void sendMessage(String message) {

        jmsTemplate.convertAndSend(MQConfig.qName, message);
    }


}
