
package com.bestbuy.ebs.dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class JsonDataResponseDTO implements Serializable {

    @JsonProperty("messageType")
    private String messageType;
    @JsonProperty("version")
    private String version;
    @JsonProperty("publishType")
    private String publishType;
    @JsonProperty("publishTimestamp")
    private String publishTimestamp;
    @JsonProperty("uuid")
    private String uuid;
    @JsonProperty("locationId")
    private int locationId;
    @JsonProperty("name")
    private String name;
    @JsonProperty("detailDesc")
    private String detailDesc;
    @JsonProperty("channel")
    private int channel;
    @JsonProperty("address1")
    private String address1;
    @JsonProperty("address2")
    private String address2;
    @JsonProperty("city")
    private String city;
    @JsonProperty("state")
    private String state;
    @JsonProperty("country")
    private String country;
    @JsonProperty("countryDesc")
    private String countryDesc;
    @JsonProperty("zipCode")
    private String zipCode;
    @JsonProperty("phoneNumber")
    private String phoneNumber;
    @JsonProperty("locationStatus")
    private String locationStatus;
    @JsonProperty("openDate")
    private String openDate;
    @JsonProperty("grandOpenDate")
    private String grandOpenDate;
    @JsonProperty("financialCloseDate")
    private String financialCloseDate;
    @JsonProperty("physicalCloseDate")
    private String physicalCloseDate;
    @JsonProperty("replenishmentStopDate")
    private String replenishmentStopDate;
    @JsonProperty("replenishmentRestartDate")
    private String replenishmentRestartDate;
    @JsonProperty("longitude")
    private Double longitude;
    @JsonProperty("latitude")
    private Double latitude;
    @JsonProperty("currencyCode")
    private String currencyCode;
    @JsonProperty("timeZoneCode")
    private String timeZoneCode;
    @JsonProperty("taxAreaId")
    private String taxAreaId;
    @JsonProperty("legalEntity")
    private int legalEntity;
    @JsonProperty("glLocation")
    private String glLocation;
    @JsonProperty("glDefaultCenter")
    private int glDefaultCenter;
    @JsonProperty("useTaxPercent")
    private Double useTaxPercent;
    @JsonProperty("storeFormat")
    private int storeFormat;
    @JsonProperty("district")
    private int district;
    @JsonProperty("districtName")
    private String districtName;
    @JsonProperty("territory")
    private int territory;
    @JsonProperty("territoryName")
    private String territoryName;
    @JsonProperty("division")
    private int division;
    @JsonProperty("divisionName")
    private String divisionName;
    @JsonProperty("locationTypeCode")
    private int locationTypeCode;
    @JsonProperty("totalSquareFeet")
    private int totalSquareFeet;
    @JsonProperty("sellingSquareFeet")
    private int sellingSquareFeet;
    @JsonProperty("ccDoingBusinessAs")
    private String ccDoingBusinessAs;
    @JsonProperty("ccStatementPhoneNumber")
    private String ccStatementPhoneNumber;
    @JsonProperty("locationCapacity")
    private int locationCapacity;
    @JsonProperty("futureLocationCapacity")
    private String futureLocationCapacity;
    @JsonProperty("futureLocCapacityStartDate")
    private String futureLocCapacityStartDate;
    @JsonProperty("inStorePickupInd")
    private String inStorePickupInd;
    @JsonProperty("homeDeliveryInd")
    private String homeDeliveryInd;
    @JsonProperty("selfDeliveryStoreInd")
    private String selfDeliveryStoreInd;
    @JsonProperty("sfsEligibleInd")
    private String sfsEligibleInd;
    @JsonProperty("obSfsEligibleInd")
    private String obSfsEligibleInd;
    @JsonProperty("partnerVisibleInd")
    private String partnerVisibleInd;
    @JsonProperty("partialPayEligibleInd")
    private String partialPayEligibleInd;
    @JsonProperty("applianceInstallInd")
    private String applianceInstallInd;
    @JsonProperty("homeTheaterInstall")
    private String homeTheaterInstall;
    @JsonProperty("transferProcessingHours")
    private String transferProcessingHours;
    @JsonProperty("attachedLocations")
    private List<AttachedLocation> attachedLocations = null;
    @JsonProperty("storeServices")
    private List<StoreService> storeServices = null;
    @JsonProperty("restrictedBrands")
    private List<RestrictedBrand> restrictedBrands = null;
    @JsonProperty("locationFunctions")
    private List<LocationFunction> locationFunctions = null;
    @JsonProperty("locationTraits")
    private List<LocationTrait> locationTraits = null;
    @JsonProperty("locationHours")
    private List<LocationHour> locationHours = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("messageType")
    public String getMessageType() {
        return messageType;
    }

    @JsonProperty("messageType")
    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    @JsonProperty("version")
    public String getVersion() {
        return version;
    }

    @JsonProperty("version")
    public void setVersion(String version) {
        this.version = version;
    }

    @JsonProperty("publishType")
    public String getPublishType() {
        return publishType;
    }

    @JsonProperty("publishType")
    public void setPublishType(String publishType) {
        this.publishType = publishType;
    }

    @JsonProperty("publishTimestamp")
    public String getPublishTimestamp() {
        return publishTimestamp;
    }

    @JsonProperty("publishTimestamp")
    public void setPublishTimestamp(String publishTimestamp) {
        this.publishTimestamp = publishTimestamp;
    }

    @JsonProperty("uuid")
    public String getUuid() {
        return uuid;
    }

    @JsonProperty("uuid")
    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    @JsonProperty("locationId")
    public int getLocationId() {
        return locationId;
    }

    @JsonProperty("locationId")
    public void setLocationId(int locationId) {
        this.locationId = locationId;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("detailDesc")
    public String getDetailDesc() {
        return detailDesc;
    }

    @JsonProperty("detailDesc")
    public void setDetailDesc(String detailDesc) {
        this.detailDesc = detailDesc;
    }

    @JsonProperty("channel")
    public int getChannel() {
        return channel;
    }

    @JsonProperty("channel")
    public void setChannel(int channel) {
        this.channel = channel;
    }

    @JsonProperty("address1")
    public String getAddress1() {
        return address1;
    }

    @JsonProperty("address1")
    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    @JsonProperty("address2")
    public String getAddress2() {
        return address2;
    }

    @JsonProperty("address2")
    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    @JsonProperty("city")
    public String getCity() {
        return city;
    }

    @JsonProperty("city")
    public void setCity(String city) {
        this.city = city;
    }

    @JsonProperty("state")
    public String getState() {
        return state;
    }

    @JsonProperty("state")
    public void setState(String state) {
        this.state = state;
    }

    @JsonProperty("country")
    public String getCountry() {
        return country;
    }

    @JsonProperty("country")
    public void setCountry(String country) {
        this.country = country;
    }

    @JsonProperty("countryDesc")
    public String getCountryDesc() {
        return countryDesc;
    }

    @JsonProperty("countryDesc")
    public void setCountryDesc(String countryDesc) {
        this.countryDesc = countryDesc;
    }

    @JsonProperty("zipCode")
    public String getZipCode() {
        return zipCode;
    }

    @JsonProperty("zipCode")
    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    @JsonProperty("phoneNumber")
    public String getPhoneNumber() {
        return phoneNumber;
    }

    @JsonProperty("phoneNumber")
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @JsonProperty("locationStatus")
    public String getLocationStatus() {
        return locationStatus;
    }

    @JsonProperty("locationStatus")
    public void setLocationStatus(String locationStatus) {
        this.locationStatus = locationStatus;
    }

    @JsonProperty("openDate")
    public String getOpenDate() {
        return openDate;
    }

    @JsonProperty("openDate")
    public void setOpenDate(String openDate) {
        this.openDate = openDate;
    }

    @JsonProperty("grandOpenDate")
    public String getGrandOpenDate() {
        return grandOpenDate;
    }

    @JsonProperty("grandOpenDate")
    public void setGrandOpenDate(String grandOpenDate) {
        this.grandOpenDate = grandOpenDate;
    }

    @JsonProperty("financialCloseDate")
    public String getFinancialCloseDate() {
        return financialCloseDate;
    }

    @JsonProperty("financialCloseDate")
    public void setFinancialCloseDate(String financialCloseDate) {
        this.financialCloseDate = financialCloseDate;
    }

    @JsonProperty("physicalCloseDate")
    public String getPhysicalCloseDate() {
        return physicalCloseDate;
    }

    @JsonProperty("physicalCloseDate")
    public void setPhysicalCloseDate(String physicalCloseDate) {
        this.physicalCloseDate = physicalCloseDate;
    }

    @JsonProperty("replenishmentStopDate")
    public String getReplenishmentStopDate() {
        return replenishmentStopDate;
    }

    @JsonProperty("replenishmentStopDate")
    public void setReplenishmentStopDate(String replenishmentStopDate) {
        this.replenishmentStopDate = replenishmentStopDate;
    }

    @JsonProperty("replenishmentRestartDate")
    public String getReplenishmentRestartDate() {
        return replenishmentRestartDate;
    }

    @JsonProperty("replenishmentRestartDate")
    public void setReplenishmentRestartDate(String replenishmentRestartDate) {
        this.replenishmentRestartDate = replenishmentRestartDate;
    }

    @JsonProperty("longitude")
    public Double getLongitude() {
        return longitude;
    }

    @JsonProperty("longitude")
    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    @JsonProperty("latitude")
    public Double getLatitude() {
        return latitude;
    }

    @JsonProperty("latitude")
    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    @JsonProperty("currencyCode")
    public String getCurrencyCode() {
        return currencyCode;
    }

    @JsonProperty("currencyCode")
    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    @JsonProperty("timeZoneCode")
    public String getTimeZoneCode() {
        return timeZoneCode;
    }

    @JsonProperty("timeZoneCode")
    public void setTimeZoneCode(String timeZoneCode) {
        this.timeZoneCode = timeZoneCode;
    }

    @JsonProperty("taxAreaId")
    public String getTaxAreaId() {
        return taxAreaId;
    }

    @JsonProperty("taxAreaId")
    public void setTaxAreaId(String taxAreaId) {
        this.taxAreaId = taxAreaId;
    }

    @JsonProperty("legalEntity")
    public int getLegalEntity() {
        return legalEntity;
    }

    @JsonProperty("legalEntity")
    public void setLegalEntity(int legalEntity) {
        this.legalEntity = legalEntity;
    }

    @JsonProperty("glLocation")
    public String getGlLocation() {
        return glLocation;
    }

    @JsonProperty("glLocation")
    public void setGlLocation(String glLocation) {
        this.glLocation = glLocation;
    }

    @JsonProperty("glDefaultCenter")
    public int getGlDefaultCenter() {
        return glDefaultCenter;
    }

    @JsonProperty("glDefaultCenter")
    public void setGlDefaultCenter(int glDefaultCenter) {
        this.glDefaultCenter = glDefaultCenter;
    }

    @JsonProperty("useTaxPercent")
    public Double getUseTaxPercent() {
        return useTaxPercent;
    }

    @JsonProperty("useTaxPercent")
    public void setUseTaxPercent(Double useTaxPercent) {
        this.useTaxPercent = useTaxPercent;
    }

    @JsonProperty("storeFormat")
    public int getStoreFormat() {
        return storeFormat;
    }

    @JsonProperty("storeFormat")
    public void setStoreFormat(int storeFormat) {
        this.storeFormat = storeFormat;
    }

    @JsonProperty("district")
    public int getDistrict() {
        return district;
    }

    @JsonProperty("district")
    public void setDistrict(int district) {
        this.district = district;
    }

    @JsonProperty("districtName")
    public String getDistrictName() {
        return districtName;
    }

    @JsonProperty("districtName")
    public void setDistrictName(String districtName) {
        this.districtName = districtName;
    }

    @JsonProperty("territory")
    public int getTerritory() {
        return territory;
    }

    @JsonProperty("territory")
    public void setTerritory(int territory) {
        this.territory = territory;
    }

    @JsonProperty("territoryName")
    public String getTerritoryName() {
        return territoryName;
    }

    @JsonProperty("territoryName")
    public void setTerritoryName(String territoryName) {
        this.territoryName = territoryName;
    }

    @JsonProperty("division")
    public int getDivision() {
        return division;
    }

    @JsonProperty("division")
    public void setDivision(int division) {
        this.division = division;
    }

    @JsonProperty("divisionName")
    public String getDivisionName() {
        return divisionName;
    }

    @JsonProperty("divisionName")
    public void setDivisionName(String divisionName) {
        this.divisionName = divisionName;
    }

    @JsonProperty("locationTypeCode")
    public int getLocationTypeCode() {
        return locationTypeCode;
    }

    @JsonProperty("locationTypeCode")
    public void setLocationTypeCode(int locationTypeCode) {
        this.locationTypeCode = locationTypeCode;
    }

    @JsonProperty("totalSquareFeet")
    public int getTotalSquareFeet() {
        return totalSquareFeet;
    }

    @JsonProperty("totalSquareFeet")
    public void setTotalSquareFeet(int totalSquareFeet) {
        this.totalSquareFeet = totalSquareFeet;
    }

    @JsonProperty("sellingSquareFeet")
    public int getSellingSquareFeet() {
        return sellingSquareFeet;
    }

    @JsonProperty("sellingSquareFeet")
    public void setSellingSquareFeet(int sellingSquareFeet) {
        this.sellingSquareFeet = sellingSquareFeet;
    }

    @JsonProperty("ccDoingBusinessAs")
    public String getCcDoingBusinessAs() {
        return ccDoingBusinessAs;
    }

    @JsonProperty("ccDoingBusinessAs")
    public void setCcDoingBusinessAs(String ccDoingBusinessAs) {
        this.ccDoingBusinessAs = ccDoingBusinessAs;
    }

    @JsonProperty("ccStatementPhoneNumber")
    public String getCcStatementPhoneNumber() {
        return ccStatementPhoneNumber;
    }

    @JsonProperty("ccStatementPhoneNumber")
    public void setCcStatementPhoneNumber(String ccStatementPhoneNumber) {
        this.ccStatementPhoneNumber = ccStatementPhoneNumber;
    }

    @JsonProperty("locationCapacity")
    public int getLocationCapacity() {
        return locationCapacity;
    }

    @JsonProperty("locationCapacity")
    public void setLocationCapacity(int locationCapacity) {
        this.locationCapacity = locationCapacity;
    }

    @JsonProperty("futureLocationCapacity")
    public String getFutureLocationCapacity() {
        return futureLocationCapacity;
    }

    @JsonProperty("futureLocationCapacity")
    public void setFutureLocationCapacity(String futureLocationCapacity) {
        this.futureLocationCapacity = futureLocationCapacity;
    }

    @JsonProperty("futureLocCapacityStartDate")
    public String getFutureLocCapacityStartDate() {
        return futureLocCapacityStartDate;
    }

    @JsonProperty("futureLocCapacityStartDate")
    public void setFutureLocCapacityStartDate(String futureLocCapacityStartDate) {
        this.futureLocCapacityStartDate = futureLocCapacityStartDate;
    }

    @JsonProperty("inStorePickupInd")
    public String getInStorePickupInd() {
        return inStorePickupInd;
    }

    @JsonProperty("inStorePickupInd")
    public void setInStorePickupInd(String inStorePickupInd) {
        this.inStorePickupInd = inStorePickupInd;
    }

    @JsonProperty("homeDeliveryInd")
    public String getHomeDeliveryInd() {
        return homeDeliveryInd;
    }

    @JsonProperty("homeDeliveryInd")
    public void setHomeDeliveryInd(String homeDeliveryInd) {
        this.homeDeliveryInd = homeDeliveryInd;
    }

    @JsonProperty("selfDeliveryStoreInd")
    public String getSelfDeliveryStoreInd() {
        return selfDeliveryStoreInd;
    }

    @JsonProperty("selfDeliveryStoreInd")
    public void setSelfDeliveryStoreInd(String selfDeliveryStoreInd) {
        this.selfDeliveryStoreInd = selfDeliveryStoreInd;
    }

    @JsonProperty("sfsEligibleInd")
    public String getSfsEligibleInd() {
        return sfsEligibleInd;
    }

    @JsonProperty("sfsEligibleInd")
    public void setSfsEligibleInd(String sfsEligibleInd) {
        this.sfsEligibleInd = sfsEligibleInd;
    }

    @JsonProperty("obSfsEligibleInd")
    public String getObSfsEligibleInd() {
        return obSfsEligibleInd;
    }

    @JsonProperty("obSfsEligibleInd")
    public void setObSfsEligibleInd(String obSfsEligibleInd) {
        this.obSfsEligibleInd = obSfsEligibleInd;
    }

    @JsonProperty("partnerVisibleInd")
    public String getPartnerVisibleInd() {
        return partnerVisibleInd;
    }

    @JsonProperty("partnerVisibleInd")
    public void setPartnerVisibleInd(String partnerVisibleInd) {
        this.partnerVisibleInd = partnerVisibleInd;
    }

    @JsonProperty("partialPayEligibleInd")
    public String getPartialPayEligibleInd() {
        return partialPayEligibleInd;
    }

    @JsonProperty("partialPayEligibleInd")
    public void setPartialPayEligibleInd(String partialPayEligibleInd) {
        this.partialPayEligibleInd = partialPayEligibleInd;
    }

    @JsonProperty("applianceInstallInd")
    public String getApplianceInstallInd() {
        return applianceInstallInd;
    }

    @JsonProperty("applianceInstallInd")
    public void setApplianceInstallInd(String applianceInstallInd) {
        this.applianceInstallInd = applianceInstallInd;
    }

    @JsonProperty("homeTheaterInstall")
    public String getHomeTheaterInstall() {
        return homeTheaterInstall;
    }

    @JsonProperty("homeTheaterInstall")
    public void setHomeTheaterInstall(String homeTheaterInstall) {
        this.homeTheaterInstall = homeTheaterInstall;
    }

    @JsonProperty("transferProcessingHours")
    public String getTransferProcessingHours() {
        return transferProcessingHours;
    }

    @JsonProperty("transferProcessingHours")
    public void setTransferProcessingHours(String transferProcessingHours) {
        this.transferProcessingHours = transferProcessingHours;
    }

    @JsonProperty("attachedLocations")
    public List<AttachedLocation> getAttachedLocations() {
        return attachedLocations;
    }

    @JsonProperty("attachedLocations")
    public void setAttachedLocations(List<AttachedLocation> attachedLocations) {
        this.attachedLocations = attachedLocations;
    }

    @JsonProperty("storeServices")
    public List<StoreService> getStoreServices() {
        return storeServices;
    }

    @JsonProperty("storeServices")
    public void setStoreServices(List<StoreService> storeServices) {
        this.storeServices = storeServices;
    }

    @JsonProperty("restrictedBrands")
    public List<RestrictedBrand> getRestrictedBrands() {
        return restrictedBrands;
    }

    @JsonProperty("restrictedBrands")
    public void setRestrictedBrands(List<RestrictedBrand> restrictedBrands) {
        this.restrictedBrands = restrictedBrands;
    }

    @JsonProperty("locationFunctions")
    public List<LocationFunction> getLocationFunctions() {
        return locationFunctions;
    }

    @JsonProperty("locationFunctions")
    public void setLocationFunctions(List<LocationFunction> locationFunctions) {
        this.locationFunctions = locationFunctions;
    }

    @JsonProperty("locationTraits")
    public List<LocationTrait> getLocationTraits() {
        return locationTraits;
    }

    @JsonProperty("locationTraits")
    public void setLocationTraits(List<LocationTrait> locationTraits) {
        this.locationTraits = locationTraits;
    }

    @JsonProperty("locationHours")
    public List<LocationHour> getLocationHours() {
        return locationHours;
    }

    @JsonProperty("locationHours")
    public void setLocationHours(List<LocationHour> locationHours) {
        this.locationHours = locationHours;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
