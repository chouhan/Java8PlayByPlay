package com.bestbuy.ebs.util;

import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.logging.LogLevel;
import org.springframework.boot.logging.LoggerConfiguration;
import org.springframework.boot.logging.logback.LogbackLoggingSystem;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import com.bestbuy.configlib.ValueChanged;

@Component
public class LogLevelConfigUtils {

	private static final Logger LOGGER = LoggerFactory.getLogger(LogLevelConfigUtils.class);

	private LogbackLoggingSystem logbackLoggingSystem;

	@Value("#{${log.component.name}}")
	private Map<String, String> components;

	public LogLevelConfigUtils() {
		logbackLoggingSystem = new LogbackLoggingSystem(this.getClass().getClassLoader());
	}

	public void configureLogLevel(String name, @Nullable LogLevel configuredLevel) {
		Assert.notNull(name, "Name must not be empty");
		logbackLoggingSystem.setLogLevel(name, configuredLevel);
	}

	public LoggerConfiguration getLoggerDetails(@Nullable String name) {
		Assert.notNull(name, "Name must not be empty");
		return logbackLoggingSystem.getLoggerConfiguration(name);
	}

	@ValueChanged({ "log.component.name" })
	public void updateLogLevel() {
		components.forEach((name, logLevel) -> {
			LogLevel logLevelObj = LogLevel.valueOf(logLevel);
			configureLogLevel((String) name, logLevelObj);
			LOGGER.info("updated log level of component with name={}, logLevel={}", name, logLevel);
		});
	}

}
