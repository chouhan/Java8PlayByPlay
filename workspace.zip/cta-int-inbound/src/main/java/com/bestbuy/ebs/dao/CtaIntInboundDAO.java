package com.bestbuy.ebs.dao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.bestbuy.ebs.model.CTAInBoundResponse;

@Service
public class CtaIntInboundDAO {

	@Autowired
	public SaveDataDAO savedata;

	private static final Logger LOGGER = LoggerFactory.getLogger(CtaIntInboundDAO.class);

	@KafkaListener(topics = "${kafka.topic.name}")
	public void listen(CTAInBoundResponse queueResponse) {
		LOGGER.info("CtaIntInboundDAO.listen Received message successfully");
		LOGGER.debug("CtaIntInboundDAO.listen Received message {}", queueResponse);
		try {
			savedata.saveToDB(queueResponse);
		} catch (Exception exception) {
			LOGGER.error("CtaIntInboundDAO.listen Exception during inbound call {} for the response {}", exception,
					queueResponse);
			throw new RuntimeException(
					"CtaIntInboundDAO.listen Error while processing the kafka messsage  " + exception);
		}
	}
}