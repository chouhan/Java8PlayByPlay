package com.bestbuy.ebs.config;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.support.serializer.JsonDeserializer;
import org.springframework.retry.backoff.ExponentialBackOffPolicy;
import org.springframework.retry.policy.AlwaysRetryPolicy;
import org.springframework.retry.support.RetryTemplate;

import com.bestbuy.ebs.model.CTAInBoundResponse;

@Configuration
public class KafkaConfig {

	@Value("${kafka.client.id}")
	String kafkaClientId;
	@Value("${bootstrap.servers}")
	String bootstrapServer;
	@Value("${security.protocol}")
	String securityProtocol;
	@Value("${sasl.mechanism}")
	String saslMechanism;
	@Value("${sasl.jaas.config}")
	String saslConfig;
	@Value("${sasl.shared.key}")
	private String sharedKey;
	@Value("${sasl.shared.key1}")
	private String sharedKey1;
	@Value("${kafka.group.id}")
	String kafkaGroupId;
	@Value("${retry.initial.interval}")
	Integer initialInterval;
	@Value("${retry.max.interval}")
	Integer maxInterval;
	@Value("${retry.backOff.multiplier}")
	Double multiplier;

	@Bean
	public Map<String, Object> consumerConfigs() {

		Map<String, Object> configProps = new HashMap<>();
		configProps.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServer);
		configProps.put("security.protocol", securityProtocol);
		configProps.put("sasl.mechanism", saslMechanism);
		configProps.put("sasl.jaas.config", saslConfig + sharedKey + sharedKey1);
		configProps.put(ConsumerConfig.GROUP_ID_CONFIG, kafkaGroupId);
		configProps.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
		configProps.put(ConsumerConfig.CLIENT_ID_CONFIG, kafkaClientId);
		configProps.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
		configProps.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
		return configProps;
	}

	@Bean
	public ConsumerFactory<String, CTAInBoundResponse> consumerFactory() {
		return new DefaultKafkaConsumerFactory<>(consumerConfigs(), new StringDeserializer(),
				new JsonDeserializer<>(CTAInBoundResponse.class));
	}

	@Bean
	public KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<String, CTAInBoundResponse>> kafkaListenerContainerFactory() {
		ConcurrentKafkaListenerContainerFactory<String, CTAInBoundResponse> factory = new ConcurrentKafkaListenerContainerFactory<>();
		factory.setConsumerFactory(consumerFactory());
		factory.getContainerProperties().setPollTimeout(3000);
		factory.setRetryTemplate(retryTemplate());
		return factory;
	}

	@Bean
	public RetryTemplate retryTemplate() {
		RetryTemplate retryTemplate = new RetryTemplate();
		retryTemplate.setRetryPolicy(new AlwaysRetryPolicy());
		retryTemplate.setBackOffPolicy(getExponentialBackOffPolicy());
		return retryTemplate;
	}

	public ExponentialBackOffPolicy getExponentialBackOffPolicy() {
		ExponentialBackOffPolicy exponentialBackOffPolicy = new ExponentialBackOffPolicy();
		exponentialBackOffPolicy.setInitialInterval(initialInterval);
		exponentialBackOffPolicy.setMultiplier(multiplier);
		exponentialBackOffPolicy.setMaxInterval(maxInterval);
		return exponentialBackOffPolicy;
	}

}
