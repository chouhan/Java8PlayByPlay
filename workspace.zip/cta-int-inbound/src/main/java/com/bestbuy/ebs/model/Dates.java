package com.bestbuy.ebs.model;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import java.io.Serializable;

@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Dates implements Serializable {

	private static final long serialVersionUID = 1993037972420388692L;

	private String customerPromisedDate;
	private String expectedDeliveryDate;
	private String previousDeliveryDate;

}
