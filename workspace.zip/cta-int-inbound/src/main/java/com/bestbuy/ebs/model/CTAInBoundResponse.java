package com.bestbuy.ebs.model;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import java.io.Serializable;

@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CTAInBoundResponse implements Serializable {

	private static final long serialVersionUID = 4114417840776152440L;

	private String sourceSystem;
	private String orderType;
	private String orderNo;
	private String trackingNo;
	private String carrierName;
	private String longDescription;
	private String statusCode1;
	private String statusCode2;
	private String statusCode3;
	private String statusCode4;
	private String statusCode5;
	private String scac;
	private String locationAddress;
	private String signerName;
	private String uuid;
	private String statusDesc;
	private String deliveryLocation;
	private String scanEventDate;
	private String milestoneCode;
	private String deliverByTime;
	private String clarifiedSignature;
	private String notifyCustomer;
	private Dates dates;

}
