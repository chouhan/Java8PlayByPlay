package com.bestbuy.ebs.dao;

import java.io.Reader;
import java.io.StringWriter;
import java.sql.Clob;
import java.sql.Types;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.CallableStatementCreatorFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Component;

import com.bestbuy.ebs.model.CTAInBoundResponse;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class SaveDataDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(SaveDataDAO.class);

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Value("${storedprocedure.values}")
	String storedProcedure;

	@Value("${interface.code}")
	String interfaceCode;

	private static final String P_INTERFACE_CODE = "P_INTERFACE_CODE";
	private static final String P_JSON_INPUT = "P_JSON_INPUT";
	private static final String X_RETURN_STATUS = "X_RETURN_STATUS";
	private static final String X_JSON_OUTPUT = "X_JSON_OUTPUT";

	public void saveToDB(CTAInBoundResponse queueResponse) {
		LOGGER.info("Calling SaveDataDAO.saveToDB method");
		try {
			ObjectMapper mapper = new ObjectMapper();
			String jsonString = mapper.writeValueAsString(queueResponse);

			List<SqlParameter> declaredParams = Arrays.asList(new SqlParameter[] {
					new SqlParameter(P_INTERFACE_CODE, Types.VARCHAR), new SqlParameter(P_JSON_INPUT, Types.CLOB),
					new SqlOutParameter(X_RETURN_STATUS, Types.VARCHAR),
					new SqlOutParameter(X_JSON_OUTPUT, Types.CLOB) });

			CallableStatementCreatorFactory cscFactory = new CallableStatementCreatorFactory(storedProcedure,
					declaredParams);

			Map<String, Object> actualParmas = new HashMap<>();
			actualParmas.put(P_INTERFACE_CODE, interfaceCode);
			actualParmas.put(P_JSON_INPUT, jsonString);
			actualParmas.put(X_RETURN_STATUS, null);
			actualParmas.put(X_JSON_OUTPUT, null);

			LOGGER.debug("SaveDataDAO.saveToDB values sending to stored procedure {} ", actualParmas);

			CallableStatementCreator callableStatementCreator = cscFactory.newCallableStatementCreator(actualParmas);
			Map<String, Object> result = jdbcTemplate.call(callableStatementCreator, declaredParams);
			Clob returnResult = (Clob) result.get(X_JSON_OUTPUT);
			String returnStatus = (String) result.get(X_RETURN_STATUS);
			LOGGER.info("SaveDataDAO.saveToDB Database call response status : {} ", returnStatus);
			if (returnResult.length() > 0) {

				char resultVal[] = new char[(int) returnResult.length()];
				Reader reader = returnResult.getCharacterStream();
				reader.read(resultVal);
				StringWriter writer = new StringWriter();
				writer.write(resultVal);

				ObjectMapper objectMapper = new ObjectMapper();
				String outputJson = writer.toString();
				LOGGER.debug("SaveDataDAO.saveToDB Database call response : {} ", outputJson);
				JsonNode actualObj = objectMapper.readTree(outputJson);
				LOGGER.debug("SaveDataDAO.saveToDB Database call actualObj : {} ", actualObj);
			}

		} catch (Exception e) {
			LOGGER.error("SaveDataDAO.saveToDB Exception from stroed procedure {}", e.toString());
			throw new RuntimeException("SaveDataDAO.saveToDB throw Exception from stroed procedure {}  " + e);
		}

	}
}
