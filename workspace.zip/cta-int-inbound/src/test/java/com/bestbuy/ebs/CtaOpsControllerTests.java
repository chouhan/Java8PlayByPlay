package com.bestbuy.ebs;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@SpringBootTest
@RunWith(SpringRunner.class)
@WebAppConfiguration
public class CtaOpsControllerTests {

	protected MockMvc mvc;

	@Autowired
	WebApplicationContext webApplicationContext;

	private static final String SET_URI = "/ops/setLoglevel?name=LogLevel&loggingLevel=INFO";
	private static final String GET_URI = "/ops/getLoglevel?componentName=test";

	@Before
	public void setUp() {
		mvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}

	@Test
	public void contextLoads() {
	}

	@Test
	public void setLoglevelSuccess() throws Exception {
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(SET_URI)).andReturn();
		assertEquals(200, mvcResult.getResponse().getStatus());
	}

	@Test
	public void getLoglevelSuccess() throws Exception {
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(GET_URI)).andReturn();
		assertEquals(200, mvcResult.getResponse().getStatus());
	}

}
