package com.bestbuy.ebs;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;

import com.bestbuy.ebs.dao.SaveDataDAO;
import com.bestbuy.ebs.dao.CtaIntInboundDAO;
import com.bestbuy.ebs.model.CTAInBoundResponse;
import com.bestbuy.ebs.model.Dates;

public class DaoTests {

	@InjectMocks
	private SaveDataDAO saveDataDAO;

	@InjectMocks
	private CtaIntInboundDAO ctaIntInboundDAO;

	@Mock
	private JdbcTemplate jdbcTemplate;

	@Mock
	private CallableStatementCreator callableStatementCreator;

	@Mock
	private List<SqlParameter> params;

	@Mock
	private Map<String, Object> result;

	private CTAInBoundResponse cTAInBoundResponse;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		cTAInBoundResponse = loadMockData();
	}

	@Test(expected = RuntimeException.class)
	public void testSaveToDBMethod() throws IOException {

		Map<String, Object> results = new HashMap<String, Object>();
		String response = "{\\r\\n\\r\\n\\\"OutputParameters\\\":{\\r\\n\\r\\n\\\"@xmlns\\\":\\\"http:\\/\\/xmlns.oracle.com\\/apps\\/inv\\/rest\\/XX_PO_PAS_CTA_TRACK_INB_PKG\\/cta_tracking_inbound_ws\\/\\\"\\r\\n\\r\\n,\\\"@xmlns:xsi\\\":\\\"http:\\/\\/www.w3.org\\/2001\\/XMLSchema-instance\\\"\\r\\n\\r\\n,\\\"X_RETURN_STATUS\\\":\\\"S\\\"\\r\\n\\r\\n,\\\"X_RETURN_CODE\\\":\\\"200\\\"\\r\\n\\r\\n,\\\"X_RETURN_MESSAGE\\\":\\\"Success\\\"\\r\\n\\r\\n}\\r\\n\\r\\n}";
		results.put("X_RETURN_STATUS", "S");
		results.put("X_JSON_OUTPUT", response);
		Mockito.when(jdbcTemplate.call(callableStatementCreator, params)).thenReturn(results);
		saveDataDAO.saveToDB(cTAInBoundResponse);

	}

	@Test(expected = RuntimeException.class)
	public void testListenMethod() throws IOException {
		Map<String, Object> results = new HashMap<String, Object>();
		Mockito.when(jdbcTemplate.call(callableStatementCreator, params)).thenReturn(results);
		ctaIntInboundDAO.listen(cTAInBoundResponse);
	}

	public CTAInBoundResponse loadMockData() {
		CTAInBoundResponse cTAInBoundResponse = new CTAInBoundResponse();
		Dates dates = new Dates();

		dates.setCustomerPromisedDate("2020-04-15");
		dates.setExpectedDeliveryDate("2020-04-15");
		dates.setPreviousDeliveryDate("2020-04-15");
		dates.toString();

		cTAInBoundResponse.setSourceSystem("MRP");
		cTAInBoundResponse.setOrderType("RGM");
		cTAInBoundResponse.setOrderNo("PO-78392920211");
		cTAInBoundResponse.setTrackingNo("1ZR448W70307983383");
		cTAInBoundResponse.setCarrierName("UPS");
		cTAInBoundResponse.setLongDescription("Origin scan");
		cTAInBoundResponse.setStatusCode1("OR");
		cTAInBoundResponse.setStatusCode2("NS");
		cTAInBoundResponse.setStatusCode3("X6");
		cTAInBoundResponse.setStatusCode4("");
		cTAInBoundResponse.setStatusCode5("");
		cTAInBoundResponse.setScac("UPS");
		cTAInBoundResponse.setLocationAddress("Bloomington, MN");
		cTAInBoundResponse.setSignerName("");
		cTAInBoundResponse.setUuid("3eaa7cf0-a35c-11e9-a7fa-2f77a47995bc");
		cTAInBoundResponse.setStatusDesc("Intransit Scan");
		cTAInBoundResponse.setDeliveryLocation("");
		cTAInBoundResponse.setScanEventDate("2020-04-09T16:46:53");
		cTAInBoundResponse.setMilestoneCode("INTRANSIT");
		cTAInBoundResponse.setDeliverByTime("");
		cTAInBoundResponse.setClarifiedSignature("");
		cTAInBoundResponse.setNotifyCustomer("");
		cTAInBoundResponse.setDates(dates);
		cTAInBoundResponse.toString();
		return cTAInBoundResponse;
	}
}
