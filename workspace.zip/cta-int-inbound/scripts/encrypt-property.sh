#!/usr/bin/env bash
echo "Encrypting the property you provided"
curl https://read.permanent:ReadPermanent@code.bestbuy.com/artifactory/simple/libs-release-local/com/bestbuy/configlib/encryptor-util/2.1.0/encryptor-util-2.1.0.zip -O
unzip encryptor-util-2.1.0.zip

export uuid=$(cat < encrypted_properties_password.txt)

if [[ $uuid == '' ]]; then
    export uuid=$(uuidgen)
    echo  "Key to paste in encrypted_properties_password.txt file is = $uuid"
fi

cd encryptor-utility-2.1.0
export encPasswd=$(sh encrypt.sh -a 'This should be a strong enough encryption passphrase for cta-int-inbound!?' -o $uuid -v $1)
echo 'ENC('$encPasswd')'
#to decrypt the value obtained from above , example
#./encrypt.sh -a 'This should be a strong enough encryption passphrase for cta-int-inbound!?'  -d  -o 'test' -v 1104L3qo/GJswKQquxpFSKft8KUj3J2pdHhn3IYqGwbL/uIcnEGOUKOJH8tCCWZSrRv0AOKa5chwfr9ISxs8LA==
