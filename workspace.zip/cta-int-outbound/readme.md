**Why we need a circuit breaker**

In case we have serviceB down, serviceA should still try to recover from this and try to do one of the followings:
Custom fallback: Try to get the same data from some other source. If not possible, use its own cache value.
Fail fast: If serviceA knows that serviceB is down, there is no point waiting for the timeout and consuming its own resources. It should return ASAP “knowing” that serviceB is down
Don’t crash: As we saw in this case, serviceA should not have crashed.
Heal automatic: Periodically check if serviceB is working again.
Other APIs should work: All other APIs should continue to work.

