package com.bestbuy.ebs.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;

@Getter
@Setter
public class Response implements Serializable {

	private static final long serialVersionUID = -6558494365956730666L;

	@ApiModelProperty(example = "Message sent successfully", value = "Message showing the status of the response")
	private String message;

	@ApiModelProperty(example = "200", value = "Http status of the response")
	private int status;

}
