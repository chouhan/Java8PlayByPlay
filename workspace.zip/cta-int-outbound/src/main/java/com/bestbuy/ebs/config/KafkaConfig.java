package com.bestbuy.ebs.config;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;

import com.bestbuy.ebs.model.Payload;

@Configuration
public class KafkaConfig {

	@Value("${kafka.client.id}")
	private String kafkaClientId;
	@Value("${bootstrap.servers}")
	private String bootstrapServer;
	@Value("${security.protocol}")
	private String securityProtocol;
	@Value("${sasl.mechanism}")
	private String saslMechanism;
	@Value("${sasl.jaas.config}")
	private String saslConfig;
	@Value("${sasl.shared.key}")
	private String sharedKey;
	@Value("${sasl.shared.key1}")
	private String sharedKey1;
	@Value("${metadata.max.age.ms}")
	private String metadataMaxAge;

	@Bean
	public Map<String, Object> producerConfigs() {

		Map<String, Object> configProps = new HashMap<>();
		configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServer);
		configProps.put("security.protocol", securityProtocol);
		configProps.put("sasl.mechanism", saslMechanism);
		configProps.put("sasl.jaas.config", saslConfig + sharedKey + sharedKey1);
		configProps.put("metadata.max.age.ms", metadataMaxAge);
		configProps.put(ProducerConfig.CLIENT_ID_CONFIG, kafkaClientId);
		configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
		return configProps;
	}

	@Bean
	public ProducerFactory<String, Payload> producerFactory() {
		return new DefaultKafkaProducerFactory<>(producerConfigs());
	}

	@Bean
	public KafkaTemplate<String, Payload> kafkaTemplate() {
		return new KafkaTemplate<>(producerFactory());
	}

}
