package com.bestbuy.ebs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Import;

import com.bestbuy.ebs.config.ApplicationConfig;

@SpringBootApplication
@Import(ApplicationConfig.class)
public class CtaIntOutboundApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(CtaIntOutboundApplication.class, args);
	}

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(CtaIntOutboundApplication.class);
	}

}
