package com.bestbuy.ebs.model;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Payload implements Serializable {

	private static final long serialVersionUID = -7604528191407671173L;

	@JsonProperty("CTAOrderReferenceData")
	@ApiModelProperty(value = "CTA Order Reference Data")
	private CTAOrderReferenceData ctaOrderReferenceData;

}
