package com.bestbuy.ebs.dao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Repository;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;
import org.springframework.web.client.HttpServerErrorException;

import com.bestbuy.ebs.model.Payload;
import com.bestbuy.ebs.model.Response;

import io.reactivex.Observable;

@Repository
public class CtaIntOutboundDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(CtaIntOutboundDAO.class);

	@Autowired
	private KafkaTemplate<String, Payload> kafkaTemplate;

	@Value("${kafka.topic.name}")
	private String topic;

	public Observable<Response> writeToQueue(Payload payload) {
		LOGGER.info("CtaIntOutboundDAO.writeToQueue - Sending to topic {}", topic);
		String topicKey = "";
		if (null != payload && null != payload.getCtaOrderReferenceData()) {
			topicKey = payload.getCtaOrderReferenceData().getTrackingNo();
		}
		ListenableFuture<SendResult<String, Payload>> future = kafkaTemplate.send(topic, topicKey, payload);
		future.addCallback(new ListenableFutureCallback<SendResult<String, Payload>>() {
			@Override
			public void onSuccess(final SendResult<String, Payload> payload) {
				LOGGER.info("CtaIntOutboundDAO.writeToQueue - Message sent successfully");
				LOGGER.debug("CtaIntOutboundDAO.onSuccess sent message {} with offset {} ", payload,
						payload.getRecordMetadata().offset());
			}

			@Override
			public void onFailure(final Throwable throwable) {
				LOGGER.error("CtaIntOutboundDAO.onFailure unable to send message {} with error {} ", payload,
						throwable);
				throw new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR, throwable.getMessage());
			}
		});

		Response res = new Response();
		res.setMessage("Message sent successfully");
		res.setStatus(200);
		return Observable.just(res);
	}

}
