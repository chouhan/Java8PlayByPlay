package com.bestbuy.ebs.model;

import javax.validation.constraints.NotBlank;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import java.io.Serializable;

@Getter
@Setter
@ToString
public class CTAOrderReferenceData implements Serializable {

	private static final long serialVersionUID = -5922195136338126691L;

	@ApiModelProperty(example = "MRP", value = "The system that generated this message")
	@NotBlank(message = "sourceSystem is mandatory")
	private String sourceSystem;

	@ApiModelProperty(example = "RGM", value = "Type of order that requires tracking?")
	@NotBlank(message = "orderType is mandatory")
	private String orderType;

	@ApiModelProperty(example = "PO-78392920211", value = "Order number associated with the order type")
	@NotBlank(message = "orderNo is mandatory")
	private String orderNo;

	@ApiModelProperty(example = "1Z144EA839028390299020", value = "The tracking number associated with the order. This could be either a parcel or LTL tracking number")
	@NotBlank(message = "trackingNo is mandatory")
	private String trackingNo;

	@ApiModelProperty(example = "UPS", value = "The name of the carrier used for shipment")
	@NotBlank(message = "carrierName is mandatory")
	private String carrierName;

	@ApiModelProperty(example = "2012-04-23T18:25:43.511Z", value = "The date/time when the item was shipped")
	@NotBlank(message = "shippedTS is mandatory")
	private String shippedTS;

	@ApiModelProperty(example = "2012-04-23", value = "The date/time when the item is expected to be delivered")
	private String customerPromisedDate;

	@ApiModelProperty(example = "PARCEL", value = "Indicates whether this shipment is a parcel or an LTL")
	private String shipmentType;

}
