package com.bestbuy.ebs.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bestbuy.ebs.dao.CtaIntOutboundDAO;
import com.bestbuy.ebs.model.Payload;
import com.bestbuy.ebs.model.Response;
import io.reactivex.Observable;

@Service
public class CtaIntOutboundService {

	@Autowired
	private CtaIntOutboundDAO dao;

	public Observable<Response> writeToCTA(Payload payload) {
		return dao.writeToQueue(payload);
	}

}
