package com.bestbuy.ebs.controller;

import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.DependsOn;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.async.DeferredResult;
import org.springframework.web.server.ResponseStatusException;

import com.bestbuy.ebs.model.Payload;
import com.bestbuy.ebs.model.Response;
import com.bestbuy.ebs.service.CtaIntOutboundService;

import io.reactivex.Observable;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@DependsOn({ "stringEncryptor" })
public class CtaIntOutboundController {

	private static final Logger LOGGER = LoggerFactory.getLogger(CtaIntOutboundController.class);

	@Autowired
	private Environment environment;

	@Autowired
	private CtaIntOutboundService ctaIntOutboundService;
	private static final String CLIENT_CODE = "clientCode";
	private static final String CLIENT_ID = "clientId";
	private static final String CLIENT_SECRET = "clientSecret";

	@ApiOperation(value = "", nickname = "SubmitOrderReferenceDataToCta", notes = "", tags = {})
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Message sent successfully", response = Response.class) })

	@PostMapping(value = { "/submit-order-reference-data-cta" }, produces = "application/json;charset=UTF-8")
	public DeferredResult<Response> writeToCTA(
			@ApiParam(value = "client identifier", required = true, example = "BU3JgqOMjYtVbZlPW1gpqssd") @RequestHeader(value = CLIENT_ID, required = true) String clientId,
			@ApiParam(value = "client Code", required = true, example = "MRP") @RequestHeader(value = CLIENT_CODE, required = true) String clientCode,
			@ApiParam(value = "client Secret", required = true, example = "mqnUCz7gezJKSsdfNrUj2uXXuYYFXGGh") @RequestHeader(value = CLIENT_SECRET, required = true) String clientSecret,
			@ApiParam(value = "payload", required = true) @RequestBody Payload payload) {
		LOGGER.info("CtaIntOutboundController.writeToCTA - Start sending message to eventhub ");
		LOGGER.debug("CtaIntOutboundController.writeToCTA - payload {} clientCode {} and clientId {}", payload,
				clientCode, clientId);

		authenticateClient(clientId, clientCode, clientSecret);

		Observable<Response> o = ctaIntOutboundService.writeToCTA(payload);
		DeferredResult<Response> deferredResult = new DeferredResult<>();
		o.subscribe(deferredResult::setResult, deferredResult::setErrorResult);
		return deferredResult;
	}

	public void authenticateClient(String clinetId, String clientCode, String clientSecret) {
		if (StringUtils.isEmpty(checkValidClientCode(clientCode))) {
			throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid clientCode");
		}
		if (!StringUtils.equalsIgnoreCase(environment.getProperty("cta.app.client.id"), clinetId)) {
			throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid clientId");
		}
		if (!StringUtils.equalsIgnoreCase(environment.getProperty("cta.app.client.secret"), clientSecret)) {
			throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid clientSecret");
		}
	}

	public String checkValidClientCode(String clientCode) {
		String clientCodes = environment.getProperty("cta.app.client.code");
		return Stream.of(clientCodes.split(",")).map(code -> new String(code))
				.filter(code -> clientCode.equalsIgnoreCase(code)).findAny().orElse(null);
	}

}
