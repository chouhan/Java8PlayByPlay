package com.bestbuy.ebs;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.bestbuy.ebs.model.CTAOrderReferenceData;
import com.bestbuy.ebs.model.Payload;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
@RunWith(SpringRunner.class)
@WebAppConfiguration
@EmbeddedKafka
@EnableKafka
@ComponentScan(basePackages = "com.bestbuy.ebs")
public class CtaIntOutboundApplicationTests {

	protected MockMvc mvc;

	@Autowired
	WebApplicationContext webApplicationContext;

	@Mock
	KafkaTemplate<String, Payload> kafkaTemplate;

	private static final String URI = "/submit-order-reference-data-cta";

	@Before
	public void setUp() {
		mvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}

	@Test
	public void contextLoads() {
	}

	@Test
	public void submitOrderSuccess() throws Exception {
		Payload payload = new Payload();
		CTAOrderReferenceData cTAOrderReferenceData = new CTAOrderReferenceData();
		cTAOrderReferenceData.setCarrierName("UPS");
		cTAOrderReferenceData.setCustomerPromisedDate("2012-04-23");
		cTAOrderReferenceData.setOrderNo("PO-78392920219");
		cTAOrderReferenceData.setOrderType("RGM");
		cTAOrderReferenceData.setShipmentType("PARCEL");
		cTAOrderReferenceData.setShippedTS("2012-04-23T18:25:43.511Z");
		cTAOrderReferenceData.setSourceSystem("MRP");
		cTAOrderReferenceData.setTrackingNo("1Z144EA839028390299028");

		payload.setCtaOrderReferenceData(cTAOrderReferenceData);
		String inputJson = mapToJson(payload);

		when(kafkaTemplate.send(anyString(), any(Payload.class))).thenReturn(null);

		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.post(URI).headers(this.setHttpHeaders())
				.contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson)).andReturn();

		assertEquals(200, mvcResult.getResponse().getStatus());
	}

	@Test
	public void submitOrderBadRequest() throws Exception {
		Payload payload = new Payload();
		String inputJson = mapToJson(payload);

		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(URI).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();

		assertEquals(400, mvcResult.getResponse().getStatus());
		assertEquals(true, mvcResult.getResponse().getErrorMessage().contains("Missing request header 'clientId' "));
	}

	@Test
	public void submitOrderWithInvalidClientId() throws Exception {
		HttpHeaders headers = setHttpHeaders();
		headers.set("clientId", "invalid");

		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.post(URI).headers(headers)
				.contentType(MediaType.APPLICATION_JSON_VALUE).content("{}")).andReturn();

		assertEquals(401, mvcResult.getResponse().getStatus());
		assertEquals(true, mvcResult.getResponse().getErrorMessage().contains("Invalid clientId"));
	}

	@Test
	public void submitOrderWithInvalidClientCode() throws Exception {
		HttpHeaders headers = setHttpHeaders();
		headers.set("clientCode", "invalid");

		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.post(URI).headers(headers)
				.contentType(MediaType.APPLICATION_JSON_VALUE).content("{}")).andReturn();

		assertEquals(401, mvcResult.getResponse().getStatus());
		assertEquals(true, mvcResult.getResponse().getErrorMessage().contains("Invalid clientCode"));
	}

	@Test
	public void submitOrderWithInvalidClientSecret() throws Exception {
		HttpHeaders headers = setHttpHeaders();
		headers.set("clientSecret", "invalid");

		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.post(URI).headers(headers)
				.contentType(MediaType.APPLICATION_JSON_VALUE).content("{}")).andReturn();

		assertEquals(401, mvcResult.getResponse().getStatus());
		assertEquals(true, mvcResult.getResponse().getErrorMessage().contains("Invalid clientSecret"));
	}

	protected String mapToJson(Object obj) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		return objectMapper.writeValueAsString(obj);
	}

	private HttpHeaders setHttpHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.set("clientId", "BU3JgqOMjYtVbZlPW1gpqpxq");
		headers.set("clientCode", "MRP");
		headers.set("clientSecret", "Test");
		headers.setContentType(MediaType.APPLICATION_JSON);
		return headers;
	}
}
