package com.bestbuy.ebs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.logging.LogLevel;
import org.springframework.boot.logging.LoggerConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.bestbuy.ebs.util.LogLevelConfigUtils;
import groovy.transform.CompileStatic;
import groovy.util.logging.Slf4j;
import io.swagger.annotations.ApiOperation;

@Slf4j
@RestController
@RequestMapping(value = "/ops")
@CompileStatic
public class EdpOpsController {

	@Autowired
	private LogLevelConfigUtils logConfigUtils;

	// This end point dynamically updates the log level of the application
	@ApiOperation(value = "setLoglevel, for setting loglevel of components", notes = "name = ROOT / package / componentName  loggingLevel = TRACE, DEBUG, INFO, WARN, ERROR, FATAL, OFF")
	@RequestMapping(value = "/setLoglevel", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<LoggerConfiguration> setLogelevel(@RequestParam(required = false) String name,
			@RequestParam String loggingLevel) {
		LogLevel logLevel = LogLevel.valueOf(loggingLevel);
		logConfigUtils.configureLogLevel(name, logLevel);
		return new ResponseEntity<LoggerConfiguration>(logConfigUtils.getLoggerDetails(name), HttpStatus.OK);
	}

	// This method gives the information about current application log level
	@ApiOperation(value = "getLoglevel, for getting loglevel of components", notes = "name = ROOT / package / componentName")
	@RequestMapping(value = "/getLoglevel", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	ResponseEntity<LoggerConfiguration> getLoglevel(@RequestParam("componentName") String componentName) {
		return new ResponseEntity<LoggerConfiguration>(logConfigUtils.getLoggerDetails(componentName), HttpStatus.OK);
	}

}
