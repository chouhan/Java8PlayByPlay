package com.bestbuy.ebs.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bestbuy.ebs.model.EventData;

@Service
public class ProcessEventDataDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProcessEventDataDAO.class);

	@Autowired
	public EventDataDAO eventDataDAO;

	@Autowired
	public ProcessTableDataDAO processTableDataDAO;

	@Value("${page.size}")
	public int pageSize;

	@Value("${topic.name.prefix}")
	private String topicPrefix;

	@Autowired
	public GcpPublishDAO gcpPublishDAO;

	// @Async("processEventData")
	public void processEventData(List<EventData> eventDataList, String tableName) {

		List<String> messageIds = eventDataList.stream().map(p -> p.getMessageId()).collect(Collectors.toList());
		eventDataDAO.updateProcessedData(messageIds, "R");

		List<String> failedMessageIds = new ArrayList<>();
		LOGGER.debug(" messageIds Payload for GCP is {}", messageIds);
		String topicName = convertToTopicName(tableName);

		for (EventData eventData : eventDataList) {
			LOGGER.debug("Payload for GCP is {}", eventData);
			try {
				gcpPublishDAO.publish(topicName, eventData.getPayload(), eventData.getMessageId() );
			} catch (Exception e) {
				LOGGER.error("Failed to publish to GCP messageIds  {}", eventData.getMessageId());
				messageIds.remove(eventData.getMessageId());
				failedMessageIds.add(eventData.getMessageId());
			}
		}
		
		LOGGER.info("Failed to published to GCP messageIds count ::::::  {}", failedMessageIds.size());
		LOGGER.info("Successfully published to GCP messageIds count ::::::  {}", messageIds.size());

		if (failedMessageIds.size() > 0) {
			LOGGER.info("Not published to GCP messageIds::::::  {}", messageIds);
		}

		eventDataDAO.updateProcessedData(messageIds, "P");
		eventDataDAO.updateProcessedData(failedMessageIds, "F");
	}

	public String convertToTopicName(String tableName) {
		LOGGER.debug("Table name=={}", tableName);
		String topicName = tableName;
		if (StringUtils.isNotBlank(tableName)) {
			topicName = topicPrefix + tableName.toLowerCase().replace("_", "-");
			LOGGER.debug("Topic name=={}", topicName);
		}
		return topicName;
	}
}
