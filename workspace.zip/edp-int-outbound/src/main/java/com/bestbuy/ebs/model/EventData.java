package com.bestbuy.ebs.model;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class EventData implements Serializable {

	private static final long serialVersionUID = 1993037972420388692L;

	private String messageId;
	private String tableName;
	private String payload;

	public EventData(String messageId, String tableName, String payload) {
		super();
		this.messageId = messageId;
		this.tableName = tableName;
		this.payload = payload;
	}

}
