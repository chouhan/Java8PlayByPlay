package com.bestbuy.ebs.config;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.gax.core.CredentialsProvider;
import com.google.api.gax.core.FixedCredentialsProvider;
import com.google.auth.oauth2.GoogleCredentials;

@Configuration
class GcpCredentialsConfig {

	private static final Logger LOGGER = LoggerFactory.getLogger(GcpCredentialsConfig.class);

	@Value("${gcp.type}")
	private String gcpType;
	@Value("${gcp.project_id}")
	private String projectId;
	@Value("${gcp.private_key_id}")
	private String privateKeyId;
	@Value("${gcp.private_key}")
	private String privateKey;
	@Value("${gcp.client_email}")
	private String clientEmail;
	@Value("${gcp.client_id}")
	private String clientId;
	@Value("${gcp.auth_uri}")
	private String authUri;
	@Value("${gcp.token_uri}")
	private String tokenUri;
	@Value("${gcp.auth_provider_x509_cert_url}")
	private String authProviderCertUrl;
	@Value("${gcp.client_x509_cert_url}")
	private String clientCertUrl;

	@Autowired
	ObjectMapper objectMapper;

	@Bean
	public CredentialsProvider credentialsProvider() {
		Map<String, String> serviceAccount = new HashMap<String, String>();
		FixedCredentialsProvider fixedCredentialsProvider = null;

		serviceAccount.put("type", gcpType);
		serviceAccount.put("project_id", projectId);
		serviceAccount.put("private_key_id", privateKeyId);
		serviceAccount.put("private_key", privateKey);
		serviceAccount.put("client_email", clientEmail);
		serviceAccount.put("client_id", clientId);
		serviceAccount.put("auth_uri", authUri);
		serviceAccount.put("token_uri", tokenUri);
		serviceAccount.put("auth_provider_x509_cert_url", authProviderCertUrl);
		serviceAccount.put("client_x509_cert_url", clientCertUrl);

		try {
			fixedCredentialsProvider = FixedCredentialsProvider.create(GoogleCredentials
					.fromStream(new ByteArrayInputStream(objectMapper.writeValueAsString(serviceAccount).getBytes())));
		} catch (JsonProcessingException e) {
			LOGGER.error("GcpCredentialsConfig JsonProcessingException during configuration {}", e);
		} catch (IOException e) {
			LOGGER.error("GcpCredentialsConfig IOException during configuration {}", e);
		}

		return fixedCredentialsProvider;

	}
}
