package com.bestbuy.ebs.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.bestbuy.ebs.dao.EventDataDAO;
import com.bestbuy.ebs.dao.ProcessTableDataDAO;
import com.bestbuy.ebs.model.TableNames;

@Component
public class ScheduledTaskService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ScheduledTaskService.class);

	@Autowired
	public EventDataDAO eventDataDAO;

	@Autowired
	public ProcessTableDataDAO processTableDataDAO;

	@Scheduled(cron = "${cron.expression}")
	public void scheduleGCPJob() {
		eventDataDAO.updateReadStatusData();
		List<TableNames> tableNames = eventDataDAO.getUniqueTableNames();

		for (TableNames tblDetails : tableNames) {
			LOGGER.info("All Table Details  {}", tblDetails);
			processTableDataDAO.processTableData(tblDetails);
		}

	}

}
