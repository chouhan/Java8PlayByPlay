package com.bestbuy.ebs.dao;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.bestbuy.ebs.model.EventData;
import com.bestbuy.ebs.model.TableNames;

@Service
public class ProcessTableDataDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProcessTableDataDAO.class);

	@Autowired
	public EventDataDAO eventDataDAO;

	@Autowired
	public ProcessEventDataDAO processEventDataDAO;

	@Value("${page.size}")
	public int pageSize;

	@Value("${topic.name.prefix}")
	private String topicPrefix;

	@Async("processTableData")
	public void processTableData(TableNames tblDetails) {
		LOGGER.debug("Execute method asynchronously.  processTableData  {}", Thread.currentThread().getName());
		String tableName = tblDetails.getTableName();
		int numberOfRecords = tblDetails.getCount();
		int totalPages = ((numberOfRecords - 1) / pageSize) + 1;
		LOGGER.info("tableName {} pageSize {}  totalPages {}", tableName, pageSize, totalPages);
		for (int pageNumber = 0; pageNumber < totalPages; pageNumber++) {
			List<EventData> eventData = eventDataDAO.getEventsData(tableName, 1, pageSize);
			LOGGER.debug("eventData size is {}  ", eventData.size());
			processEventDataDAO.processEventData(eventData, tableName);
		}
	}

}
