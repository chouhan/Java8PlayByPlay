package com.bestbuy.ebs.dao;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.bestbuy.ebs.model.EventData;
import com.bestbuy.ebs.model.TableNames;

@Component
public class EventDataDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(EventDataDAO.class);

	@Autowired
	JdbcTemplate jdbcTemplate;

	private static final String GET_UNIQUE_TABLE_NAMES = "SELECT DISTINCT TABLE_NAME, COUNT(*) COUNT FROM XX.XX_FND_MSG_OUT_GCP where RECORD_STATUS='N' GROUP BY TABLE_NAME";
	private static final String UPDATE_READ_DATA = "update XX.XX_FND_MSG_OUT_GCP set RECORD_STATUS='N' where RECORD_STATUS='R'";

	public void updateReadStatusData() {
		LOGGER.debug("Calling updateReadStatusData method");
		int updatedRows = jdbcTemplate.update(UPDATE_READ_DATA);
		LOGGER.debug("updatedRowsToNotProcessed  {}", updatedRows);
	}

	public List<TableNames> getUniqueTableNames() {
		LOGGER.info("Calling getUniqueTableNames method");
		List<TableNames> uniqueTables = jdbcTemplate.query(GET_UNIQUE_TABLE_NAMES,
				(rs, rowNum) -> new TableNames(rs.getInt("COUNT"), rs.getString("TABLE_NAME")));
		LOGGER.info("uniqueTables {}", uniqueTables);
		return uniqueTables;
	}

	public List<EventData> getEventsData(String tableName, int startIndex, int endIndex) {
		LOGGER.debug("Calling getEventsData method for tableName {} startIndex {} and endIndex {}", tableName,
				startIndex, endIndex);
		long start = System.currentTimeMillis();
		String sql = "Select * from (select gcp.*, rownum rn from (select * from XX.XX_FND_MSG_OUT_GCP where TABLE_NAME=? and RECORD_STATUS='N' order by message_id) gcp) where rn between ? and ?";
		List<EventData> eventData = jdbcTemplate.query(sql, new Object[] { tableName, startIndex, endIndex },
				(rs, rowNum) -> new EventData(rs.getString("MESSAGE_ID"), rs.getString("TABLE_NAME"),
						rs.getString("PAYLOAD")));

		LOGGER.debug("getEventsData Elapsed time: {}", System.currentTimeMillis() - start);
		return eventData;
	}

	public void updateProcessedData(List<String> messageIds, String status) {
		LOGGER.debug("Calling updateProcessedData method messageIds{}", messageIds);
		if (CollectionUtils.isNotEmpty(messageIds)) {
			String sql = String.format(
					"update XX.XX_FND_MSG_OUT_GCP set RECORD_STATUS= ? , RECORD_PROCESSED_DATE=sysdate , LAST_UPDATE_DATE=sysdate , LAST_UPDATED_BY=-1"
							+ " where MESSAGE_ID in (%s)",
					String.join(",", messageIds));
			int updatedRows = jdbcTemplate.update(sql, new Object[] { status });
			LOGGER.debug("updatedRows  {}", updatedRows);
		}
	}
}
