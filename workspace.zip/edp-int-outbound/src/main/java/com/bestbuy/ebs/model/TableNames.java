package com.bestbuy.ebs.model;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TableNames implements Serializable {

	private static final long serialVersionUID = 1993037972420388692L;

	private int count;
	private String tableName;

	public TableNames(int count, String tableName) {
		super();
		this.count = count;
		this.tableName = tableName;
	}

}
