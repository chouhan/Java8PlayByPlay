package com.bestbuy.ebs.config;

import java.util.concurrent.Executor;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.filter.RequestContextFilter;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.bestbuy.configlib.encryption.config.EnvironmentBasedEncryptorConfig;
import com.bestbuy.configlib.endpoints.springmvc.ConfigEndpointSpringConfig;
import com.bestbuy.configlib.heartbeat.LiveConfigHeartbeatConfig;
import com.bestbuy.configlib.spring.MultipleSourceLiveConfigSpringConfiguration;
import com.bestbuy.operational.endpoints.healthcheck.encryption.EncryptionHealthCheck;
import com.bestbuy.operational.endpoints.healthcheck.infra.InfraHealthChecksSpringConfig;
import com.bestbuy.operational.endpoints.healthcheck.liveconfig.LiveConfigHealthCheckSpringConfig;
import com.bestbuy.operational.endpoints.springmvc.AwakeController;
import com.bestbuy.operational.endpoints.springmvc.HealthCheckController;
import com.bestbuy.operational.endpoints.springmvc.HeartbeatController;
import com.bestbuy.operational.endpoints.springmvc.SpringMvcHeartbeatHealthCheckConfig;

import groovy.transform.CompileStatic;

@CompileStatic
@Configuration
@EnableAsync

@ComponentScan(basePackages = { "com.bestbuy.ebs" }, excludeFilters = {
		@ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, classes = { AwakeController.class,
				HeartbeatController.class, HealthCheckController.class }) })

@Import(value = { SpringMvcHeartbeatHealthCheckConfig.class, MultipleSourceLiveConfigSpringConfiguration.class,
		ConfigEndpointSpringConfig.class, InfraHealthChecksSpringConfig.class, LiveConfigHeartbeatConfig.class,
		EnvironmentBasedEncryptorConfig.class, LiveConfigHealthCheckSpringConfig.class })

@PropertySources({ @PropertySource(value = "classpath:/config/default.properties", ignoreResourceNotFound = true),
		@PropertySource(value = "classpath:/config/environments/${environment:local}.properties", ignoreResourceNotFound = true),
		@PropertySource(value = "classpath:/config/environments/${environment}-${region}.properties", ignoreResourceNotFound = true),
		@PropertySource(value = "classpath:/config/environments${environment}-${region}-${farm}.properties", ignoreResourceNotFound = true),
		@PropertySource(value = "${app.config}/environment.properties", ignoreResourceNotFound = true) })
public class ApplicationConfig implements ApplicationContextAware, WebMvcConfigurer {

	private static final String[] CLASSPATH_RESOURCE_LOCATIONS = { "classpath:/META-INF/resources/",
			"classpath:/resources/", "classpath:/public/", "classpath:/templates/", "classpath:/static/",
			"classpath:/META-INF/resources/" };

	@Autowired
	ApplicationContext applicationContext;

	@Bean
	static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}

	@Bean
	EncryptionHealthCheck encryptionHealthCheck(ConfigurableEnvironment environment) {
		return new EncryptionHealthCheck(environment);
	}

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/**").addResourceLocations(CLASSPATH_RESOURCE_LOCATIONS);
		registry.addResourceHandler("swagger-ui.html").addResourceLocations("classpath:/META-INF/resources/");
		registry.addResourceHandler("/webjars/**").addResourceLocations("classpath:/META-INF/resources/webjars/");
	}

	@Bean
	public RequestContextFilter requestContextFilter() {
		RequestContextFilter requestContextFilter = new RequestContextFilter();
		requestContextFilter.setThreadContextInheritable(true);
		return requestContextFilter;
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext = applicationContext;
	}

	@Bean(name = "processTableData")
	public Executor asyncProcessTableData() {
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(30);
		executor.setMaxPoolSize(40);
		executor.setQueueCapacity(500);
		executor.setThreadNamePrefix("AsyncTableData-");
		executor.initialize();
		return executor;
	}

	@Bean(name = "processEventData")
	public Executor asyncProcessEventData() {
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(40);
		executor.setMaxPoolSize(50);
		executor.setQueueCapacity(500);
		executor.setThreadNamePrefix("AsyncEventData-");
		executor.initialize();
		return executor;
	}

}
