package com.bestbuy.ebs.dao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.gcp.pubsub.core.PubSubTemplate;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

@Service
public class GcpPublishDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(GcpPublishDAO.class);
	private PubSubTemplate pubSubTemplate;

	private static final int MAX_ATTEMPTS = 5;
	private static final int BACK_OFF = 2000;

	public GcpPublishDAO(PubSubTemplate pubSubTemplate) {
		this.pubSubTemplate = pubSubTemplate;
	}

	@Retryable(value = { Exception.class }, maxAttempts = MAX_ATTEMPTS, backoff = @Backoff(BACK_OFF))
	public void publish(String topicName, String message, String messageId) throws RuntimeException {
		LOGGER.debug("Publishing to the topic", topicName);
		try {
			String refId = this.pubSubTemplate.publish(topicName, message).get();
			LOGGER.info("After Publishing to the topic {} refId {} for messageId {} ", topicName, refId, messageId);
		} catch (Exception e) {
			LOGGER.info("Error occured during publishing to the topic {} for messageId {}", topicName, messageId);
			throw new RuntimeException();
		}
	}

}
