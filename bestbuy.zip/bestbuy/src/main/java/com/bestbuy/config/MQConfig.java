package com.bestbuy.config;

public class MQConfig {

    public static final String qName = "DEV.QUEUE.1";
}
