package com.bestbuy.receiver;

import com.bestbuy.config.MQConfig;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class MessageReceiver {

    @JmsListener(destination = MQConfig.qName)
    public void receiveMessage(String msg) {
        System.out.println();
        System.out.println("========================================");
        System.out.println("Received message is: " + msg);
        System.out.println("========================================");

    }
}
