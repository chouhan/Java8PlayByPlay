package com.bestbuy.ebs.repository;

import com.bestbuy.ebs.model.Spps;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface SppsRepository extends CrudRepository<Spps, String> {

    @Query("Select * from spps")
    List<Spps> findAll();

    List<Spps> findByMessageType(String messageType);

}

