package com.bestbuy.ebs.service;

import com.bestbuy.ebs.model.Spps;
import com.bestbuy.ebs.repository.SppsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Collection;
import java.util.Date;
import java.util.List;


@Service
public class SppsServiceImpl implements SppsService {


    @Autowired
    private SppsRepository sppsRepository;

	@Override
	public void insertData(String data, String messageType) {

		List<Spps> list = getSppsByMessageType(messageType);

		if(!list.isEmpty()) {
			Spps eSpps = list.get(0);
			eSpps.setJsondata(data);
			eSpps.setLast_updated_timestamp(Timestamp.from(Instant.now()));
			sppsRepository.save(eSpps);
		} else {

			Spps spps = new Spps();
			spps.setId(3);
			spps.setJsondata(data);
			spps.setLast_processed_timestamp(null);
			spps.setLast_updated_timestamp(Timestamp.from(Instant.now()));
			spps.setMessageType(messageType);
			spps.setStatus("Unprocessed");
			sppsRepository.save(spps);
		}
		
	}

	public List<Spps> getSppsByMessageType(String messageType) {
		List<Spps> list = sppsRepository.findByMessageType(messageType);
		return list;
	}




}
