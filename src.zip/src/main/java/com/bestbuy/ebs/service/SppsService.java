package com.bestbuy.ebs.service;


import com.bestbuy.ebs.model.Spps;

import java.util.Collection;
import java.util.List;

public interface SppsService {

	public void insertData(String data,String messageType);

	public List<Spps> getSppsByMessageType(String messageType);
	
}
