package com.bestbuy.ebs.util;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

public class SSHConnection {

	public static void main(String args[]) throws JSchException {

		JSch jsch = new JSch();		
	//	Session session = jsch.getSession("sudarshan", "35.200.129.175", 22);
		Session session = jsch.getSession("root", "34.135.220.143", 22);
		//QA
	//	Session session = jsch.getSession("sudarshan", "35.189.158.136", 22);
		session.setPassword("OnyApp@123");
		jsch.addIdentity("C://personal//project//rar-api//ony_new", "OnyApp@123");
		//jsch.addIdentity("C://development//retailer//key//retailerapp_staging//retailerapp_stagging", "aspl@101");
		//	jsch.addIdentity("sudarshan", "aspl@101");
		java.util.Properties config = new java.util.Properties();
		config.put("StrictHostKeyChecking", "no");
		config.put("ConnectionAttempts", "3");
		session.setConfig(config);
		session.connect();
		System.out.println("SSH Connected");

		int localPort = 8740; // any free port can be used
		String remoteHost = "localhost";
		int remotePort = 9042;
		int assinged_port = session.setPortForwardingL(localPort, remoteHost, remotePort);
	}
}